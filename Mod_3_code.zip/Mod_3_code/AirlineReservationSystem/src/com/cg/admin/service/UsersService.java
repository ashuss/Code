package com.cg.admin.service;

import com.cg.admin.dto.Users;
import com.cg.admin.exception.UserException;

public interface UsersService 
{
	public int insertUser(Users user)throws UserException;
	public boolean fetchParticularUser(String username,String password)throws UserException;
	public int fetchRole(String username,String password)throws UserException;
    public boolean validateMobileNo(long mNo) throws UserException;
    public boolean validateUsername(String uName) throws UserException;
    public boolean validatePassword(String uPwd) throws UserException;

}
