package com.cg.user.dto;

import java.util.Date;

public class BillDetails 
{
	private int bill_num;
	private long con_num;
	private float cur_read;
	private float unit_con;
	private float net_amt;
	private Date bill_date;
	
	
	public int getBill_num() 
	{
		return bill_num;
	}
	public void setBill_num(int bill_num) 
	{
		this.bill_num = bill_num;
	}
	public long getCon_num() 
	{
		return con_num;
	}
	public void setCon_num(long con_num) 
	{
		this.con_num = con_num;
	}
	public float getCur_read() 
	{
		return cur_read;
	}
	public void setCur_read(float cur_read) 
	{
		this.cur_read = cur_read;
	}
	public float getUnit_con() 
	{
		return unit_con;
	}
	public void setUnit_con(float unit_con) 
	{
		this.unit_con = unit_con;
	}
	public float getNet_amt() 
	{
		return net_amt;
	}
	public void setNet_amt(float net_amt) 
	{
		this.net_amt = net_amt;
	}
	public Date getBill_date() 
	{
		return bill_date;
	}
	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}
	
	
	
	public BillDetails() 
	{
		super();
	}
	
	
	public BillDetails(int bill_num, long con_num, float cur_read,
			float unit_con, float net_amt, Date bill_date) 
	{
		super();
		this.bill_num = bill_num;
		this.con_num = con_num;
		this.cur_read = cur_read;
		this.unit_con = unit_con;
		this.net_amt = net_amt;
		this.bill_date = bill_date;
	}
	
	
	@Override
	public String toString() 
	{
		return "BillDetails [bill_num=" + bill_num + ", con_num=" + con_num
				+ ", cur_read=" + cur_read + ", unit_con=" + unit_con
				+ ", net_amt=" + net_amt + ", bill_date=" + bill_date + "]";
	}
	
	
	
	
	
	
	
	
	
}
