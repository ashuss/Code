package com.cg.user.dto;

public class Login 
{
	private int conNum;
	private String password;
	
	//Getter Setter
	public int getConNum() 
	{
		return conNum;
	}
	public void setConNum(int conNum) 
	{
		this.conNum = conNum;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	
	//Empty Constructor
	public Login()
	{
		super();
	}
	
	//Field constructor
	public Login(int conNum, String password) 
	{
		super();
		this.conNum = conNum;
		this.password = password;
	}
	
	
	//toString function
	@Override
	public String toString() 
	{
		return "Login [conNum=" + conNum + ", password=" + password + "]";
	}
	
	
	
	
	
	
	
	
}
