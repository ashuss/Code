package com.cg.user.cntrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.user.dto.Login;
import com.cg.user.service.LoginService;
import com.cg.user.service.LoginServiceImpl;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	ServletConfig cg = null;
    LoginService logSer = null;
   
    public LoginController() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cg = config;
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String action = request.getParameter("action");
		HttpSession session = request.getSession(true);
		RequestDispatcher rd = null;
		logSer = new LoginServiceImpl();
		if(action != null)
		{
			try
			{
				/*****************ShowWelcomePage*************/
				
				if(action.equals("ShowWelcomePage"))
				{
					rd = request.getRequestDispatcher("Pages/Welcome.jsp");
					rd.forward(request, response);
				
				}
				/*************End ShowWelcomePage****************/
				
				/*****************ShowloginPage*************/
				
				if(action.equals("ShowloginPage"))
				{
					rd = request.getRequestDispatcher("Pages/Login.jsp");
					rd.forward(request, response);
				}
				/*****************End ShowloginPage*************/
				
/********************ShowSuccessPage**********/
				
				if(action.equals("ShowSuccessPage"))
				{
					String conNum = (String)request.getParameter("txtCNum");
					int num = Integer.parseInt(conNum);
					String pwd = request.getParameter("txtPwd");
					/*Login user = logSer.getUserByCNum(num);
					
					if((user.getConNum() == num) && (user.getPassword().equalsIgnoreCase(pwd)))
					{
						session.setAttribute("UserNameObj", conNum);
						rd = request.getRequestDispatcher("SuccessPage");
						rd.forward(request, response);
					}
					else
					{
						String msg = "Sorry! Please Ckeck Your Password";
						request.setAttribute("ErrorMsgObj", msg);
						rd = request.getRequestDispatcher("Pages/Login.jsp");
						rd.forward(request, response);
					}*/
				}
		
				/********************End ShowSuccessPage**********/
			}
			catch(Exception ee)
			{
				String erMsg = ee.getMessage();
				request.setAttribute("ErrorMsgObj", erMsg);
				
				RequestDispatcher rdError = request.getRequestDispatcher("ShowErrorPage");
				rdError.forward(request, response);
			}
		}
		else
		{
			response.getWriter().println("No action Defined ... ");
		}
	}

}
