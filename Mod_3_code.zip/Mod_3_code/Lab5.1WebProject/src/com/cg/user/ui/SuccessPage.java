package com.cg.user.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/SuccessPage")
public class SuccessPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ServletConfig cg = null;
    public SuccessPage()
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cg = config;
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		HttpSession ses = request.getSession(true);
		int num = (int) ses.getAttribute("UserNumberObj");
		out.println("<b>Welcome To EBill Application:</b>"+num);
		out.println("<b>You Are Valid user :</b>");
		out.println("<hr color = 'green' size = '2'>");
		out.println("<a href = ''>Pay Bill</a><br/>");
		
	}

}
