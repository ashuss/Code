package com.cg.user.service;

import java.util.ArrayList;

import com.cg.user.dto.BillDetails;
import com.cg.user.exception.BillException;

public interface BillDetailsService 
{
	public int addbillDetails(BillDetails bill)
	throws BillException;
			
	public int generateBillNum()
	throws BillException;
			
	public ArrayList<Long> getCusumerId()
	throws BillException;
			
	public String getConsumerName(long consumerNo)
	throws BillException;
	
	public boolean validateConsumerId(long cId)
	throws BillException;
	
	public boolean validateMeterReading(float lastMonRead, float curMonRead)
	throws BillException;
}
