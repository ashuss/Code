package com.cg.user.service;

import java.util.ArrayList;

import com.cg.user.dao.BillDetailsDao;
import com.cg.user.dao.BillDetailsDaoImpl;
import com.cg.user.dto.BillDetails;
import com.cg.user.exception.BillException;

public class BillDetailsServiceImpl 
implements BillDetailsService
{
	BillDetailsDao billDao = null;
	
	public BillDetailsServiceImpl()
	{
		billDao = new BillDetailsDaoImpl();
	}
	
	@Override
	public int addbillDetails(BillDetails bill) throws BillException 
	{
		return billDao.addbillDetails(bill);
	}

	@Override
	public int generateBillNum() throws BillException 
	{
		return 0;
	}

	@Override
	public ArrayList<Long> getCusumerId() throws BillException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getConsumerName(long consumerNo) throws BillException 
	{
		return billDao.getConsumerName(consumerNo);
	}

	@Override
	public boolean validateConsumerId(long cId) throws BillException 
	{
		ArrayList<Long> conId = new ArrayList<Long>();
		conId = billDao.getCusumerId();
		int flag = 0;
		for(Long i:conId)
			
	}

	@Override
	public boolean validateMeterReading(float lastMonRead, float curMonRead)
			throws BillException {
		// TODO Auto-generated method stub
		return false;
	}

	

}
