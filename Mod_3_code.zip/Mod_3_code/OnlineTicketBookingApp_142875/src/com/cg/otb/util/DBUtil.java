package com.cg.otb.util;

import java.sql.Connection;
import java.sql.DriverManager;

//import javax.naming.InitialContext;


import com.cg.otb.exception.BookException;

public class DBUtil
{
	public static Connection getCon()
			throws BookException
			{
				Connection con = null;
				//InitialContext context;
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
					con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
					/*context = new InitialContext();
					DataSource ds = (DataSource)context.lookup("java:/jdbc/OracleDS");
					con = ds.getConnection();*/
				}
				 catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(con);
				return con;
			}
}
