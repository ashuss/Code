package com.cg.otb.dto;

public class Customer 
{
	private String cus_name;
	private String mobileNo;
	private int noOfTicket;
	public String getCus_name() {
		return cus_name;
	}
	public void setCus_name(String cus_name) {
		this.cus_name = cus_name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getNoOfTicket() {
		return noOfTicket;
	}
	public void setNoOfTicket(int noOfTicket) {
		this.noOfTicket = noOfTicket;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String cus_name, String mobileNo, int noOfTicket) {
		super();
		this.cus_name = cus_name;
		this.mobileNo = mobileNo;
		this.noOfTicket = noOfTicket;
	}
	@Override
	public String toString() {
		return "Customer [cus_name=" + cus_name + ", mobileNo=" + mobileNo
				+ ", noOfTicket=" + noOfTicket + "]";
	}
	
	
}
