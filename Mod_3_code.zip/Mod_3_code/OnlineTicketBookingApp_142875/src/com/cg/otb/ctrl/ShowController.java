package com.cg.otb.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.otb.dto.BookTicket;
import com.cg.otb.service.BookTicketService;
import com.cg.otb.service.BookTicketServiceImpl;


/**
 * Servlet implementation class ShowController
 */
@WebServlet("/ShowController")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 ServletConfig cg = null;
     BookTicketService btSer = null;
   
    public ShowController() 
    {
        super();
       
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		cg = config;
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() 
	{
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String action = request.getParameter("action");
		HttpSession session = request.getSession(true);
		RequestDispatcher rd = null;
		btSer = new BookTicketServiceImpl();
		if(action != null)
		{
			try
			{
				if(action.equals("ShowHomePage"))
				{
					rd = request.getRequestDispatcher("Home.jsp");
					rd.forward(request, response);
				}
				if(action.equals("ShowBookPage"))
				{
					String showNm = request.getParameter("uName");
					String p = request.getParameter("price");
					float price = Float.parseFloat(p);
					String cNm = request.getParameter("cName");
					String mobile = request.getParameter("phoneNo");
					String s = request.getParameter("totalS");
					int num = Integer.parseInt(s);
					String n = request.getParameter("noOfSeats");
					int nn = Integer.parseInt(n);
					rd = request.getRequestDispatcher("Home.jsp");
					rd.forward(request, response);
					int bt = btSer.updateShowDetails(nn, showNm); 
					
					if(nn > 0)
					{
						float total = nn * price;
						session.setAttribute("tList",bt );
						rd = request.getRequestDispatcher("Success.jsp");
						rd.forward(request, response);
						
					}
				}
				
			}
			catch(Exception ee)
			{
				String erMsg = ee.getMessage();
				request.setAttribute("ErrorMsgObj", erMsg);
				
				RequestDispatcher rdError = request.getRequestDispatcher("ShowErrorPage");
				rdError.forward(request, response);
			}
		}
		else
		{
			response.getWriter().println("No action Defined ... ");
		}
	}

}
