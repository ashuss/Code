package com.cg.otb.service;

import java.util.List;

import com.cg.otb.dao.BookTicketDao;
import com.cg.otb.dao.BookTicketDaoImpl;
import com.cg.otb.dto.BookTicket;
import com.cg.otb.exception.BookException;

public class BookTicketServiceImpl 
implements BookTicketService
{
	BookTicketDao btDao = new BookTicketDaoImpl();

	@Override
	public List<BookTicket> getAllShows() throws BookException 
	{
		return btDao.getAllShows();
	}

	@Override
	public int updateShowDetails(int tickets, String showNm)
			throws BookException 
	{
		return btDao.updateShowDetails(tickets, showNm);
	}

	@Override
	public boolean validateAvSeats(int avSeat) throws BookException 
	{
		int flag = 0;
		if(avSeat > 0)
		{
			flag = 1;
		}
		if(flag==1)
		{
			return true;
		}

		else
		{
			throw new BookException("Sold ");
		}
		
	}

}
