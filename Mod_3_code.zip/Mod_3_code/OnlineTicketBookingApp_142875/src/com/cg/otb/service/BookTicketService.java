package com.cg.otb.service;

import java.util.List;

import com.cg.otb.dto.BookTicket;
import com.cg.otb.exception.BookException;

public interface BookTicketService 
{
	List<BookTicket> getAllShows() throws BookException;
	
	int updateShowDetails(int tickets ,String showNm)throws BookException;
	
	public boolean validateAvSeats(int avSeat) throws BookException;

}
