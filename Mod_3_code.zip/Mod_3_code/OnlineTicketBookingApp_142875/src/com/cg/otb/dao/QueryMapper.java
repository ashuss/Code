package com.cg.otb.dao;

public interface QueryMapper 
{
	String SELECT_ALL_Shows = "SELECT ShowName, Location, ShowDate, AvSeats, PriceTicket FROM ShowDetails";
	
	String UPDATE_Shows = "UPDATE ShowDetails SET AvSeats = AvSeats - (?) WHERE ShowName = (?)";
}
