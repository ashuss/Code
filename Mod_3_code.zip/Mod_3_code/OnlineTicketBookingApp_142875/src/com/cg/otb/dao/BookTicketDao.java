package com.cg.otb.dao;

import com.cg.otb.dto.BookTicket;

import java.util.List;

import com.cg.otb.exception.BookException;

public interface BookTicketDao 
{
	List<BookTicket> getAllShows() throws BookException;
	
	int updateShowDetails(int tickets ,String showNm)throws BookException;
}
