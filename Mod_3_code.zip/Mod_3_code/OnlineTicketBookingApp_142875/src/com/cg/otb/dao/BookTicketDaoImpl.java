package com.cg.otb.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.cg.otb.dto.BookTicket;
import com.cg.otb.exception.BookException;
import com.cg.otb.util.DBUtil;

public class BookTicketDaoImpl 
implements BookTicketDao
{
	Connection con = null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	
	
	@Override
	public List<BookTicket> getAllShows() throws BookException 
	{
		
		List<BookTicket> showList = new ArrayList<BookTicket>();
		
		con = DBUtil.getCon();

		try 
		{
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.SELECT_ALL_Shows);

			while(rs.next())
			{
				BookTicket bt = new BookTicket();
				
				bt.setShowName(rs.getString("showName"));
				bt.setLocation(rs.getString("Location"));
				bt.setShowDate(rs.getDate("ShowDate"));
				bt.setAvSeats(rs.getInt("AvSeats"));
				bt.setPriceTicket(rs.getFloat("PriceTicket"));
				
				showList.add(bt);
			}
		}
		catch (SQLException e) 
		{
			throw new BookException("Problem in Fetching Show list"+e.getMessage());
		}
		
		return showList;
	}

	/**********************************************************************/
	

	@Override
	public int updateShowDetails(int tickets, String showNm)
			throws BookException 
	{
		con=DBUtil.getCon();
        int dataUpdated=0;
        try
        {
        PreparedStatement pst=con.prepareStatement(QueryMapper.UPDATE_Shows);

        pst.setInt(1,tickets);
        pst.setString(2,showNm);
        dataUpdated=pst.executeUpdate();
          
        }
        catch (SQLException e)
        {
            throw new BookException("Problem in updating Show Deatisl "+e.getMessage());
        }
       
        return dataUpdated;
	}

}
