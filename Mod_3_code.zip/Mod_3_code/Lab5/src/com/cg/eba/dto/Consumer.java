package com.cg.eba.dto;

public class Consumer 
{
	private long consumerNum;
	private String consumerName;
	private String consumerAdd;
	public long getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getConsumerAdd() {
		return consumerAdd;
	}
	public void setConsumerAdd(String consumerAdd) {
		this.consumerAdd = consumerAdd;
	}
	public Consumer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Consumer(long consumerNum, String consumerName, String consumerAdd) {
		super();
		this.consumerNum = consumerNum;
		this.consumerName = consumerName;
		this.consumerAdd = consumerAdd;
	}
	@Override
	public String toString() {
		return "Consumer [consumerNum=" + consumerNum + ", consumerName="
				+ consumerName + ", consumerAdd=" + consumerAdd + "]";
	}
	
	
	
}
