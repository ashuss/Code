package com.cg.eba.dao;

import java.sql.*;
import java.util.ArrayList;

import com.cg.eba.dto.Ebill;
import com.cg.eba.exception.BillException;
import com.cg.eba.util.DBUtil;

public class EbillDaoImpl implements  EbillDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public int addBillDetails(Ebill bill) throws BillException 
	{
		String insertQry="insert into billdetails(bill_num,consumer_num,cur_reading,"
				+ "unitConsumed,netAmount) values(?,?,?,?,?)";
		int dataAdded=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, genetateBillNum());
			pst.setLong(2, bill.getConsumerNum());
			pst.setFloat(3, bill.getCurrReading());
			pst.setFloat(4, bill.getUnitsConsumed());
			pst.setFloat(5, bill.getNetAmount());
			dataAdded=pst.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new BillException(e.getMessage());
		}
		return dataAdded;
	}

	public  int genetateBillNum() throws BillException 
	{
		String qry="Select seq_bill_num.NEXTVAL from dual";
		int generatedVal=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
		} 
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new BillException(e.getMessage());
			}
		}
		return generatedVal;
	}
	
	@Override
	public ArrayList<Long> getCustomerId() throws BillException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomerName(Long consumerNo) throws BillException {
		// TODO Auto-generated method stub
		return null;
	}

}
