package com.cg.eba.dao;

import java.util.ArrayList;

import com.cg.eba.dto.Ebill;
import com.cg.eba.exception.BillException;

public interface EbillDao 
{
	public int addBillDetails(Ebill bill) throws BillException;
	public ArrayList<Long> getCustomerId()  throws BillException;
	public String getCustomerName(Long consumerNo) throws BillException;
}
