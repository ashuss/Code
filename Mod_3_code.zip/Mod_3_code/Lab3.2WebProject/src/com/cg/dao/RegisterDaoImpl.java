package com.cg.dao;

import java.sql.*;

import com.cg.dto.Register;
import com.cg.util.DBUtil;

public class RegisterDaoImpl 
implements RegisterDao 
{
	Connection con=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    int dataAdded=0;
    
    public int insertDetails(Register reg) throws SQLException 
    {
        String insertQry="Insert into RegisteredUsers( firstname,lastname,password,gender,skillset,city) values(?,?,?,?,?,?)";
        try 
        {
            con=DBUtil.getCon();
            pst=con.prepareStatement(insertQry);
            pst.setString(1,reg.getFirstname());
            pst.setString(2,reg.getLastName());
            pst.setString(3,reg.getPassword());
            pst.setString(4,reg.getGender());
            pst.setString(5,reg.getSkillSet());
            pst.setString(6,reg.getCity());
            dataAdded = pst.executeUpdate();    
            
        } 
        catch (Exception e)
        {
            
            throw new SQLException(e.getMessage());
        } 
        finally
        {
            try
            {
                pst.close();
                con.close();
            }
            catch(SQLException e)
            {
                throw new SQLException(e.getMessage());
            }
        }
        
        return dataAdded;
    }
    
}
