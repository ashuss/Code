package com.cg.user.dao;

import java.sql.SQLException;

import com.cg.user.dto.Login;
import com.cg.user.exception.LoginException;

public interface LoginDao 
{
	public Login getUserByUnm(String unm)
	throws LoginException;
}
