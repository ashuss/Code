package com.cg.pmc.dao;

import java.util.List;

import com.cg.pmc.exception.FirmException;
import com.cg.pmc.dto.FirmMaster;

public interface FirmMasterDao 
{
	List<FirmMaster> getAllData()
	throws FirmException;
	
	FirmMaster getFirmData(long firmId)
	throws FirmException;
	
	int addFirmDetails(FirmMaster firm)
	throws FirmException;
	
}
