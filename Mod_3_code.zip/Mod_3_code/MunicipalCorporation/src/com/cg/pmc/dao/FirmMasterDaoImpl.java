package com.cg.pmc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.pmc.dto.FirmMaster;
import com.cg.pmc.exception.FirmException;
import com.cg.pmc.util.DBUtil;

public class FirmMasterDaoImpl 
implements FirmMasterDao
{
	
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	Statement st = null;

	@Override
	public List<FirmMaster> getAllData() throws FirmException 
	{
		List<FirmMaster> firmList = new ArrayList<FirmMaster>();
        String selectQry="SELECT * FROM FIRMS_MASTER";
        FirmMaster fm;
        try 
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(selectQry);
            
            while(rs.next())
            {
                fm = new FirmMaster(rs.getLong("firmId"),rs.getString("owner_name"),
                		rs.getString("business_name"),rs.getString("emailId"),
                		rs.getString("mobileNo"),rs.getString("isActive"));
                firmList.add(fm);
            }
        } 
        catch (Exception e)
        {
            throw new FirmException(e.getMessage()); 
        }       
        
        
        return firmList;
	}

	/**********************************************************************************/
	
	@Override
	public FirmMaster getFirmData(long firmId) throws FirmException 
	{
		FirmMaster fm = null;
		try
		{
		con = DBUtil.getCon();
		System.out.println("Got Connection : ");
		String qry = "SELECT * FROM FIRMS_MASTER WHERE firm_id = ?";
		pst = con.prepareStatement(qry);
		pst.setLong(1, firmId);
		rs = pst.executeQuery();
		rs.next();
		fm = new FirmMaster(rs.getLong("firmId"),rs.getString("owner_name"),
				rs.getString("business_name"),rs.getString("emailId"),
				rs.getString("mobileNo"),rs.getString("isActive"));	


		}
		catch(SQLException se)
		{
			throw new FirmException(se.getMessage());
		}
		return fm;
	}

	/********************************************************************************/
	
	@Override
	public int addFirmDetails(FirmMaster firm) throws FirmException 
	{
		FirmMaster fm = null;
		String insertQry="Insert into FIRMS_MASTER values(?,?,?,?,?,?)";   
		int dataAdded = 0;
		try
		{
			 con=DBUtil.getCon();
	         pst=con.prepareStatement(insertQry);
	         
	         pst.setLong(1, generateFirmId());
	         pst.setString(2, fm.getOwner_name());
	         pst.setString(3, fm.getBusiness_name());
	         pst.setString(4, fm.getEmailId());
	         pst.setString(5, fm.getMobileNo());
	         pst.setString(6, fm.getIsActive());
	         
	         dataAdded = pst.executeUpdate(); 
		}
		catch (Exception e)
        {
            
            throw new FirmException(e.getMessage());
        } 
        
        
        return dataAdded;
	}
	
	/**********************************************************************************/
	
	private long generateFirmId() throws FirmException
	{
		String qry="Select seq_firm_master.NEXTVAL FROM DUAL";
        long generatedVal;
        try 
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(qry);
            
            rs.next();
            generatedVal=rs.getLong(1);
            
        }
        catch (Exception e) 
        {
            throw new FirmException(e.getMessage());     //exception not handled
        } 
        
        return generatedVal;
	}

}
