package com.cg.pmc.dto;

public class FirmMaster 
{

	private long firmId;
	private String owner_name;
	private String business_name;
	private String emailId;
	private String mobileNo;
	private String isActive;
	
	
	public long getFirmId() 
	{
		return firmId;
	}
	public void setFirmId(long firmId) 
	{
		this.firmId = firmId;
	}
	public String getOwner_name() 
	{
		return owner_name;
	}
	public void setOwner_name(String owner_name) 
	{
		this.owner_name = owner_name;
	}
	public String getBusiness_name() 
	{
		return business_name;
	}
	public void setBusiness_name(String business_name) 
	{
		this.business_name = business_name;
	}
	public String getEmailId() 
	{
		return emailId;
	}
	public void setEmailId(String emailId) 
	{
		this.emailId = emailId;
	}
	public String getMobileNo() 
	{
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) 
	{
		this.mobileNo = mobileNo;
	}
	public String getIsActive() 
	{
		return isActive;
	}
	public void setIsActive(String isActive) 
	{
		this.isActive = isActive;
	}
	
	
	public FirmMaster() 
	{
		super();
	}
	
	
	public FirmMaster(long firmId, String owner_name, String business_name,
			String emailId, String mobileNo, String isActive) 
	{
		super();
		this.firmId = firmId;
		this.owner_name = owner_name;
		this.business_name = business_name;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.isActive = isActive;
	}
	
	
	@Override
	public String toString() 
	{
		return "FirmMaster [firmId=" + firmId + ", owner_name=" + owner_name
				+ ", business_name=" + business_name + ", emailId=" + emailId
				+ ", mobileNo=" + mobileNo + ", isActive=" + isActive + "]";
	}
	
	
	
}
