package com.cg.pmc.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/ShowSuccessPage")
public class ShowSuccessPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ServletConfig cg = null;
    public ShowSuccessPage() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cg = config;
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		HttpSession ses = request.getSession(true);
		long firm_id = (long)ses.getAttribute("Firm");
		out.println("<h2>Your Firm is Successfully registered.</h2>");
		out.println("<h2>Activate your account with following activation code.</h2>");
		out.println(""+firm_id);
		out.println("<a href='Home.jsp'>Home</a>");
	}

}
