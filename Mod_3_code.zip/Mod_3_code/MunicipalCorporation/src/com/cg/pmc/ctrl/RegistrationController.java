package com.cg.pmc.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.pmc.dto.FirmMaster;
import com.cg.pmc.service.FirmMasterService;
import com.cg.pmc.service.FirmMasterServiceImpl;




@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	FirmMasterService fmSer = null;  
	ServletConfig cg = null;
    
    
    public RegistrationController() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cg = config;
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String action = request.getParameter("action");
		HttpSession session = request.getSession(true);
		RequestDispatcher rd = null;
		FirmMaster fm;
		fmSer = new FirmMasterServiceImpl();
		
		if(action != null)
		{
			try
			{
				/*****************ShowWelcomePage*************/
				
				if(action.equals("ShowWelcomePage"))
				{
					rd = request.getRequestDispatcher("Home.jsp");
					rd.forward(request, response);
				
				}
				/*************End ShowWelcomePage****************/
				
				/*****************ShowRegisterPage*************/
				
				if(action.equals("ShowRegisterPage"))
				{
					rd = request.getRequestDispatcher("Register.jsp");
					rd.forward(request, response);
				}
				/*****************End ShowRegisterPage*************/
				
				/********************ShowSuccessPage**********/
				
				if(action.equals("ShowSuccessPage"))
				{
					String unm = request.getParameter("uName");
					String bnm = request.getParameter("bName");
					String email = request.getParameter("emailId");
					String mob = request.getParameter("mob");
					fm=(FirmMaster)session.getAttribute("fm");

					session = request.getSession(false);
					
					request.setAttribute("Firm", fm);
					rd = request.getRequestDispatcher("Success.jsp");
					rd.forward(request, response);
				}
				
			}
			catch(Exception ee)
			{
				String erMsg = ee.getMessage();
				request.setAttribute("ErrorMsgObj", erMsg);
				
				RequestDispatcher rdError = request.getRequestDispatcher("Error.jsp");
				rdError.forward(request, response);
			}
		}
		else
		{
			response.getWriter().println("No action Defined ... ");
		}
	}

}
