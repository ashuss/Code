package com.cg.pmc.service;

import java.util.List;

import com.cg.pmc.dto.FirmMaster;
import com.cg.pmc.exception.FirmException;

public interface FirmMasterService 
{
	List<FirmMaster> getAllData()
			throws FirmException;
			
	FirmMaster getFirmData(long firmId)
			throws FirmException;
			
	int addFirmDetails(FirmMaster firm)
			throws FirmException;

}
