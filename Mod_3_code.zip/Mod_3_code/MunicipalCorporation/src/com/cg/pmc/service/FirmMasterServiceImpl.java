package com.cg.pmc.service;

import java.util.List;

import com.cg.pmc.dao.FirmMasterDao;
import com.cg.pmc.dao.FirmMasterDaoImpl;
import com.cg.pmc.dto.FirmMaster;
import com.cg.pmc.exception.FirmException;

public class FirmMasterServiceImpl 
implements FirmMasterService
{
	FirmMasterDao fmDao=new FirmMasterDaoImpl();

	@Override
	public List<FirmMaster> getAllData() throws FirmException 
	{
		return fmDao.getAllData();
	}

	@Override
	public FirmMaster getFirmData(long firmId) throws FirmException
	{
		return fmDao.getFirmData(firmId);
	}

	@Override
	public int addFirmDetails(FirmMaster firm) throws FirmException 
	{

        return fmDao.addFirmDetails(firm);
	}

}
