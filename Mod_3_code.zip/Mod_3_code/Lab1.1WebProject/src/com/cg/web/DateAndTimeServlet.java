package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name="DateAndTimeServletname", urlPatterns={"/DateAndTimeServletMap"})
public class DateAndTimeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DateAndTimeServlet() 
    {
        super();
        System.out.println(" Empty Constructor");
    }

	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("Init of DateAndTimeServlet Called");
	}

	
	public void destroy() 
	{
		System.out.println("InDestroy Of DateAndTimeServletCalled");
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		LocalDate date = LocalDate.now();
		PrintWriter out = response.getWriter();
		out.println("Today's Date is : "+date);
	}

}
