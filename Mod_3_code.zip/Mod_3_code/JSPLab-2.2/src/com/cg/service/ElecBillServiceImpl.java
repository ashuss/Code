package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.ElecBillDao;
import com.cg.dao.ElecBillDaoImpl;
import com.cg.dto.Consumer;
import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;
import com.cg.exception.ConsumerException;

public class ElecBillServiceImpl implements ElecBillService
{
	ElecBillDao elecBillDao=null;
	public ElecBillServiceImpl()
	{
		elecBillDao=new ElecBillDaoImpl();
	}
	@Override
	public int addBillDetails(ElectricityBill elecBill) throws BillException,Exception
	{

		return elecBillDao.addBillDetails(elecBill);
	}

	@Override
	public long generateBillNumber() throws BillException,Exception
	{

		return elecBillDao.generateBillNumber();
	}

	@Override
	public boolean validateLMonMeterReading(float lMonMeterReading)
			throws BillException,Exception
	{
		if(lMonMeterReading<0)
		{
			throw new BillException("Last Month meter Reading should be greater than zero");
		}
		else
		{
			return true;
		}

	}

	@Override
	public boolean validateCMonMeterReading(float cMonMeterReading)
			throws BillException,Exception
	{
		if(cMonMeterReading<0)
		{
			throw new BillException("Current Month meter Reading should be greater than zero");
		}
		else
		{
			return true;
		}


	}

	@Override
	public boolean validateMeterReading(float lMonMeterReading,float cMonMeterReading)
			throws BillException,Exception
	{
		if(cMonMeterReading<lMonMeterReading)
		{
			throw new BillException("Current Month meter Reading should be greater than LastMonth Reading");
		}
		else
		{
			return true;
		}
	}
	public float calcUnitConsumed(float lMonMeterReading,float cMonMeterReading)
			throws BillException,Exception
	{
		float unitConsumed=cMonMeterReading-lMonMeterReading;
		return unitConsumed;
	}
	public float calcNetAmount(float unitConsumed)throws BillException,Exception
	{
		final int fixedCharge=100;
		float netAmount=(float) (unitConsumed*1.15+fixedCharge);
		return netAmount;
	}


	@Override
	public boolean validateConsumerNumber(int consumerNumber)
			throws Exception,BillException
	{
		int flag=0;
		ArrayList<Integer> consuNoList=elecBillDao.getConsumerNo();
		for(int tempConsNo :consuNoList)
		{
			if(consumerNumber==tempConsNo)
			{
				flag=1;
			}

		}
		if(flag==1)
		{
			return true;
		}

		else
		{
			throw new BillException("Invalid Consumer Number Please Check it.");
		}

	}
	@Override
	public String getConsumerName(int consumerNumber) throws BillException,Exception
	{

		return elecBillDao.getConsumerName(consumerNumber);
	}
	@Override
	public ArrayList<Consumer> getAllConsumerDetails() throws ConsumerException 
	{		
		return elecBillDao.getAllConsumerDetails();
	}
	@Override
	public Consumer getConsumerById(long consumerNumber)
			throws ConsumerException
	{
		return elecBillDao.getConsumerById(consumerNumber);
	}
	@Override
	public ArrayList<ElectricityBill> showBillDetails(long consumerNo)
			throws BillException
			{
		
		return elecBillDao.showBillDetails(consumerNo);
	}

}
