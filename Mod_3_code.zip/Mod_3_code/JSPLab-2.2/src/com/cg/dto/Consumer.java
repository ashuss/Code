package com.cg.dto;

public class Consumer
{
	private long consumerNo;
	private String consumerName;
	private String address;

	public Consumer() 
	{
		super();

	}

	public long getConsumerNo() 
	{
		return consumerNo;
	}

	public void setConsumerNo(long consumerNo)
	{
		this.consumerNo = consumerNo;
	}

	public String getConsumerName() 
	{
		return consumerName;
	}

	public void setConsumerName(String consumerName)
	{
		this.consumerName = consumerName;
	}

	public String getAddress() 
	{
		return address;
	}

	public void setAddress(String address) 
	{
		this.address = address;
	}

	public Consumer(long consumerNo, String consumerName, String address) 
	{
		super();
		this.consumerNo = consumerNo;
		this.consumerName = consumerName;
		this.address = address;
	}

	@Override
	public String toString()
	{
		return "Consumer [consumerNo=" + consumerNo + ", consumerName="
				+ consumerName + ", address=" + address + "]";
	}

}
