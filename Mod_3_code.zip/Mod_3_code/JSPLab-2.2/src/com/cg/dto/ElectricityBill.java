package com.cg.dto;

import java.time.LocalDate;

public class ElectricityBill 
{
	private long billNumber;
	private long consumerNumber;
	private float currMonthReading;
	private float unitConsumed;
	private float netAmount;
	private LocalDate billDate;
	public long getBillNumber()
	{
		return billNumber;
	}
	public void setBillNumber(long billNumber)
	{
		this.billNumber = billNumber;
	}
	public long getConsumerNumber()
	{
		return consumerNumber;
	}
	public void setConsumerNumber(long consumerNumber)
	{
		this.consumerNumber = consumerNumber;
	}
	public float getCurrMonthReading()
	{
		return currMonthReading;
	}
	public void setCurrMonthReading(float currMonthReading) 
	{
		this.currMonthReading = currMonthReading;
	}
	public float getUnitConsumed() 
	{
		return unitConsumed;
	}
	public void setUnitConsumed(float unitConsumed) 
	{
		this.unitConsumed = unitConsumed;
	}
	public float getNetAmount() 
	{
		return netAmount;
	}
	public void setNetAmount(float netAmount) 
	{
		this.netAmount = netAmount;
	}
	public LocalDate getBillDate() 
	{
		return billDate;
	}
	public void setBillDate(LocalDate billDate) 
	{
		this.billDate = billDate;
	}
	public ElectricityBill(long billNumber, long consumerNumber,
			float currMonthReading, float unitConsumed, float netAmount,
			LocalDate billDate)
	{
		super();
		this.billNumber = billNumber;
		this.consumerNumber = consumerNumber;
		this.currMonthReading = currMonthReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}
	public ElectricityBill() 
	{
		super();
	}
	@Override
	public String toString() 
	{
		return "ElectricityBill [billNumber=" + billNumber
				+ ", consumerNumber=" + consumerNumber + ", currMonthReading="
				+ currMonthReading + ", unitConsumed=" + unitConsumed
				+ ", netAmount=" + netAmount + ", billDate=" + billDate + "]";
	}
	
	
}
