package com.cg.ctrl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Consumer;
import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;
import com.cg.exception.ConsumerException;
import com.cg.service.ElecBillService;
import com.cg.service.ElecBillServiceImpl;
import com.sun.mail.iap.Response;



@WebServlet(urlPatterns={"/home","/Search","/ShowBillDetails","/GenerateNextBill"})
public class EBillController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    ElecBillService elecBillSer=null;
    ElectricityBill elecBill=null;
    Consumer cons=null;
    int dataAdded=0;
    HttpSession session=null;
    public EBillController()
    {
    	elecBillSer=new ElecBillServiceImpl();
    	elecBill=new ElectricityBill();
    	
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		session=request.getSession(true);
		String url=request.getServletPath();
		String targetUrl="";
		switch(url)
		{
		case "/home" :
			ArrayList<Consumer> consList;
			try
			{
				consList=elecBillSer.getAllConsumerDetails();
				request.setAttribute("consListObj", consList);
				targetUrl="ShowConsumerList.jsp";
			} 
			catch (ConsumerException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			
			break;
		case "/Search":
			long consuNumber=Long.parseLong(request.getParameter("txtConsuNo"));
			Consumer cons=null;
			try 
			{
				cons=elecBillSer.getConsumerById(consuNumber);
				HttpSession sess=request.getSession(true);
				sess.setAttribute("ConsumerObj", cons);
				targetUrl="ShowConsumer.jsp";
			} 
			catch (ConsumerException e)
			{				
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			
			break;
		case "/ShowBillDetails":
			ArrayList<ElectricityBill> bills;
			long consumerNo=Long.parseLong(request.getParameter("consumerNo"));
			try
			{
				bills=elecBillSer.showBillDetails(consumerNo);
				request.setAttribute("ConsumerNoObj", consumerNo);
				request.setAttribute("billsObj", bills); 
				//System.out.println(bills);
				targetUrl="ShowBillDetails.jsp";
			} 
			catch (BillException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		case "/GenerateNextBill":
			cons=new Consumer();
			try 
			{
				String lMonReading=request.getParameter("LMonMeterReading");
				String CMonReading=request.getParameter("CMonMeterReading");
				String consNo=request.getParameter("txtConsumerNo");
				//out.println(lMonReading+CMonReading+consumerNo);

				float lMonMeterReading=Float.parseFloat(lMonReading);
				float cMonMeterReading=Float.parseFloat(CMonReading);
				int consumerNumber=Integer.parseInt(consNo);
				elecBillSer=new ElecBillServiceImpl();

				if(elecBillSer.validateLMonMeterReading(lMonMeterReading))
				{
					if(elecBillSer.validateCMonMeterReading(cMonMeterReading))
					{
						if(elecBillSer.validateMeterReading(lMonMeterReading, cMonMeterReading))
						{	
							if(elecBillSer.validateConsumerNumber(consumerNumber))
							{
								float unitConsumed=elecBillSer.calcUnitConsumed(lMonMeterReading, cMonMeterReading);
								float netAmount=elecBillSer.calcNetAmount(unitConsumed);
								elecBill=new ElectricityBill();
								elecBill.setBillNumber(elecBillSer.generateBillNumber());
								elecBill.setConsumerNumber(consumerNumber);
								elecBill.setCurrMonthReading(cMonMeterReading);
								elecBill.setUnitConsumed(unitConsumed);
								elecBill.setNetAmount(netAmount);
								dataAdded=elecBillSer.addBillDetails(elecBill);
								if(dataAdded==1)
								{
									session=request.getSession(true);
									session.setAttribute("ConsumerNameObj", elecBillSer.getConsumerName(consumerNumber));
									session.setAttribute("ConsumerNumberObj", consumerNumber);
									session.setAttribute("UnitConsumedObj", unitConsumed);
									session.setAttribute("NetAmountObj", netAmount);
									targetUrl="SuccessGenNextBill.jsp";
								}
							}
						}
					}
				}
			
				
			} 
			catch (Exception e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
				e.printStackTrace();
			} 
			break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
