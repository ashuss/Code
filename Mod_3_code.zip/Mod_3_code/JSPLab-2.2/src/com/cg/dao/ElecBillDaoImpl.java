package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.dto.Consumer;
import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;
import com.cg.exception.ConsumerException;
import com.cg.util.DBUtil;

public class ElecBillDaoImpl implements ElecBillDao
{
	Connection con=null;
	PreparedStatement pst=null;
	Statement st=null;
	ResultSet rs=null;
	int dataAdded=0;
	Consumer cons=null;
	@Override
	public int addBillDetails(ElectricityBill elecBill) throws Exception,BillException
	{
		try
		{
		con=DBUtil.getCon();
		String insertQry="INSERT INTO BillDetails VALUES(?,?,?,?,?,sysdate)";
		pst=con.prepareStatement(insertQry);
		pst.setLong(1, elecBill.getBillNumber());
		pst.setFloat(2, elecBill.getConsumerNumber());
		pst.setFloat(3, elecBill.getCurrMonthReading());
		pst.setFloat(4, elecBill.getUnitConsumed());
		pst.setFloat(5,elecBill.getNetAmount());
		dataAdded=pst.executeUpdate();
		}
		catch(Exception e)
		{
			//throw new BillException(e.getMessage());
			e.printStackTrace();
		}
		return dataAdded;
	}
	public long generateBillNumber() throws Exception,BillException
	{		
		String qry="Select seq_bill_num.NEXTVAL FROM DUAL";
		int generatedVal=0;
		
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
			
		}
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		} 
		
		
		return generatedVal;
	}
	@Override
	public ArrayList<Integer> getConsumerNo() throws Exception,BillException
	{
		ArrayList<Integer> consuNoList=new ArrayList<Integer>();
		String qry="SELECT consumer_num FROM Consumers";
		int generatedConsuNo=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			
			while(rs.next())
			{
				generatedConsuNo=rs.getInt(1);
				consuNoList.add(generatedConsuNo);
			}
			
			
			
		}
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		} 
		return consuNoList;
	}
	@Override
	public String getConsumerName(int consumerNumber) throws Exception,BillException
	{
		String qry="SELECT consumer_name FROM Consumers where consumer_num=?";
		String consumerName=null;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setInt(1, consumerNumber);
			rs=pst.executeQuery();
			rs.next();
			consumerName=rs.getString("consumer_name");
		}
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		} 
		return consumerName;
	}
	@Override
	public ArrayList<Consumer> getAllConsumerDetails() 
			throws ConsumerException 
	{
		
		ArrayList<Consumer> consuList=new ArrayList<Consumer>();
		String qry="SELECT * FROM Consumers";
		
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			
			while(rs.next())
			{
				cons=new Consumer();
				cons.setConsumerNo(rs.getLong("consumer_num"));
				cons.setConsumerName(rs.getString("consumer_name"));
				cons.setAddress(rs.getString("address"));
				consuList.add(cons);
			}			
		}
		catch (Exception e) 
		{
			throw new ConsumerException("Problem in fetching Consumer list"+e.getMessage());
		} 
		return consuList;
	}
	@Override
	public Consumer getConsumerById(long consumerNumber) throws ConsumerException
	{
		String qry="SELECT * FROM Consumers where consumer_num=?";
		
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setLong(1, consumerNumber);
			rs=pst.executeQuery();
			rs.next();
			cons=new Consumer();
			cons.setConsumerNo(rs.getLong("consumer_num"));
			cons.setConsumerName(rs.getString("consumer_name"));
			cons.setAddress(rs.getString("address"));
		}
		catch (Exception e) 
		{
			throw new ConsumerException("Problem in fetching the Consumer"+e.getMessage());
		} 
		return cons;
		
	}
	@Override
	public ArrayList<ElectricityBill> showBillDetails(long consumerNo) throws BillException
	{
		ArrayList<ElectricityBill> bills=new ArrayList<ElectricityBill>();
		ElectricityBill elecBill=null;
		String qry="SELECT * FROM billdetails where consumer_num=?";
		try 
		{
			elecBill=new  ElectricityBill();
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setLong(1, consumerNo);
			rs=pst.executeQuery();
			while(rs.next())
			{
				elecBill.setBillNumber(rs.getLong("bill_num"));
				elecBill.setConsumerNumber(rs.getLong("consumer_num"));
				elecBill.setCurrMonthReading(rs.getFloat("cur_reading"));
				elecBill.setUnitConsumed(rs.getFloat("unitconsumed"));
				elecBill.setNetAmount(rs.getFloat("netamount"));
				elecBill.setBillDate(rs.getDate("bill_date").toLocalDate());
				bills.add(elecBill);
			}
		}
		catch (Exception e) 
		{
			throw new BillException("Problem in fetching the Consumer Bill Details"+e.getMessage());
		}
		
		return bills;
	}
}
