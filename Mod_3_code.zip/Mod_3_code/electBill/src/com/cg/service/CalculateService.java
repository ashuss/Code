package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Bill;
import com.cg.exception.BillException;

public interface CalculateService
{
	public int addBillDetails(Bill bill) throws BillException;
	public ArrayList<Long> getCustomerId()  throws BillException;
	public String getCustomerName(Long consumerNo) throws BillException;
	public boolean validateCustomerId(long cId) throws BillException;
	public boolean validateMeterReading
	(float lMonReading,float cMonReading) throws BillException;
}
