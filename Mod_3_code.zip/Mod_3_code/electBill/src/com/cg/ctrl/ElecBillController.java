package com.cg.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Bill;
import com.cg.service.CalculateService;
import com.cg.service.CalculateServiceImpl;




@WebServlet("/ElecBillController")
public class ElecBillController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	ServletConfig cg=null;
	CalculateService calcServ=null;
	Bill bill=null;
	private static final float fixedCharge = 100.0F;

	public ElecBillController() 
	{
		super();

	}


	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cg=config;
	}


	public void destroy() 
	{

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, 
			IOException 
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			IOException 
	{
		calcServ=new CalculateServiceImpl();
		bill=new Bill();
		String action=request.getParameter("action");	
		HttpSession session=request.getSession(true);
		RequestDispatcher rd=null;
		if(action!=null)
		{		
			try
			{
				/*************Show Welcome Page*******/
				if(action.equals("ShowWelcomePage"))
				{
					rd=request.getRequestDispatcher
							("Pages/Welcome.jsp");
					rd.forward(request, response);

				}
				/*************End Welcome Page*******/
				/*****Login page*****/
				if(action.equals("ShowLoginPage"))
				{
					rd=request.getRequestDispatcher
							("Pages/Login.jsp");
					rd.forward(request, response);
					/*******End Login page***/
				}
				/********ShowSucesspage*******/
				if(action.equals("ShowSuccessPage"))
				{
					String unm=request.getParameter("txtName");
					String pwd=request.getParameter("password");

					if((("admin").equalsIgnoreCase(unm))&&
							(("admin").equalsIgnoreCase(pwd)))
					{

						rd=request.getRequestDispatcher("Pages/Success.jsp");
						rd.forward(request, response);
					}
					else
					{
						String msg="Sorryy- Please check your Password";
						request.setAttribute("ErrorMsgObj" , msg);
						rd=request.getRequestDispatcher("Pages/Login.jsp");
						rd.forward(request, response);

					}

				}
				/*************End SuccessPage*******************/
				if(action.equals("ShowSuccessPage2"))
				{
					String cId=request.getParameter("ConNum");
					String last_reading=request.getParameter("lastReading");
					String cuu_reading=request.getParameter("currentReading");

					float last=Float.parseFloat(last_reading);
					float curr=Float.parseFloat(cuu_reading);
					long consNo=Long.parseLong(cId);
					float unitsConsumed=0.0F;
					float netAmount=0.0F;
					int dataAdded=0;
					System.out.println(cId);
					if(calcServ.validateCustomerId(consNo) && 
							calcServ.validateMeterReading(last, curr))
					{
						
						unitsConsumed=curr-last;
						netAmount=unitsConsumed*1.15F+fixedCharge;
						bill.setConsumerNum(consNo);
						bill.setCurrReading(curr);
						bill.setNetAmount(netAmount);
						bill.setUnitsConsumed(unitsConsumed);
						System.out.println(netAmount);
						dataAdded=calcServ.addBillDetails(bill);
						if(dataAdded==1)
						{
							session.setAttribute("ConsumerNo", consNo);
							session.setAttribute("Units", unitsConsumed);
							session.setAttribute("NetAmt", netAmount);
							rd=request.getRequestDispatcher("DisplayServlet");
							rd.forward(request, response);
						}
						else
						{
							rd=request.getRequestDispatcher("InsertionFail.html");
							rd.forward(request, response);
						}
					}
				}

				/********EndShowSucesspage*******/
			}
			catch(Exception ee)
			{
			String  erMsg=ee.getMessage();
			request.setAttribute("ErrorMsgObj"  , erMsg);
			RequestDispatcher rdError=
					request.getRequestDispatcher("ShowErrorPage");
			rdError.forward(request, response);
			}


		}


	}

}

