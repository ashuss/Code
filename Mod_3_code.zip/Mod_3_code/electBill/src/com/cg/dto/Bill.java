package com.cg.dto;

import java.time.LocalDate;

public class Bill
{
	private long billNum;
	private long consumerNum;
	private float currReading;
	private float unitsConsumed;
	private float netAmount;
	LocalDate date;
	public long getBillNum()
	{
		return billNum;
	}
	public void setBillNum(long billNum) 
	{
		this.billNum = billNum;
	}
	public long getConsumerNum()
	{
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum)
	{
		this.consumerNum = consumerNum;
	}
	public float getCurrReading()
	{
		
		return currReading;
	}
	public void setCurrReading(float currReading)
	{
		this.currReading = currReading;
	}
	public float getUnitsConsumed()
	{
		return unitsConsumed;
	}
	public void setUnitsConsumed(float unitsConsumed)
	{
		this.unitsConsumed = unitsConsumed;
	}
	public float getNetAmount()
	{
		return netAmount;
	}
	public void setNetAmount(float netAmount)
	{
		this.netAmount = netAmount;
	}
	public LocalDate getDate()
	{
		return date;
	}
	public void setDate(LocalDate date)
	{
		this.date = date;
	}
	public Bill(long billNum, long consumerNum, float currReading,
			float unitsConsumed, float netAmount, LocalDate date)
	{
		super();
		this.billNum = billNum;
		this.consumerNum = consumerNum;
		this.currReading = currReading;
		this.unitsConsumed = unitsConsumed;
		this.netAmount = netAmount;
		this.date = date;
	}
	public Bill()
	{
		super();
	}
	@Override
	public String toString()
	{
		return "BillDetails [billNum=" + billNum + ", consumerNum="
				+ consumerNum + ", currReading=" + currReading
				+ ", unitsConsumed=" + unitsConsumed + ", netAmount="
				+ netAmount + ", date=" + date + "]";
	}
	
	
	
}
