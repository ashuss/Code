package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Bill;
import com.cg.exception.BillException;

public interface CalculateDao
{
	public int addBillDetails(Bill bill) throws BillException;
	public ArrayList<Long> getCustomerId()  throws BillException;
	public String getCustomerName(Long consumerNo) throws BillException;
}
