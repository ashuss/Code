package com.cg.mpa.dao;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.dto.PurchaseDetails;
import java.util.List;

public interface MobilePurchaseDao 
{
	List<Mobile> getAllMob() throws MobileException;
	Mobile getMobile(int mobId) throws MobileException;
	int addPurchaseDetails(PurchaseDetails purchase) throws MobileException;
}
