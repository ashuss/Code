package com.cg.mpa.dto;

public class Mobile 
{
	private int mobId;
	private String mobName;
	private float price;
	private int quantity;
	
	public int getMobId() 
	{
		return mobId;
	}
	public void setMobId(int mobId) 
	{
		this.mobId = mobId;
	}
	public String getMobName() 
	{
		return mobName;
	}
	public void setMobName(String mobName)
	{
		this.mobName = mobName;
	}
	public float getPrice() 
	{
		return price;
	}
	public void setPrice(float price) 
	{
		this.price = price;
	}
	public int getQuantity()
	{
		return quantity;
	}
	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	
	@Override
	public String toString()
	{
		return "Mobile [mobId=" + mobId + ", mobName=" + mobName + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
	
	public Mobile()
	{
		super();
	}
	
	public Mobile(int mobId, String mobName, float price, int quantity) 
	{
		super();
		this.mobId = mobId;
		this.mobName = mobName;
		this.price = price;
		this.quantity = quantity;
	}
	
}
