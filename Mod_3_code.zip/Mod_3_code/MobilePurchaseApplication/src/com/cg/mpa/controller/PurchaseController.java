package com.cg.mpa.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.service.MobileService;
import com.cg.mpa.service.MobileServiceImpl;

@WebServlet(urlPatterns={"/home","/buy","/purchase"})
public class PurchaseController extends HttpServlet
{
	Mobile mob =null;
	private static final long serialVersionUID = 1L;
  
    public PurchaseController() 
    {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException
	{
		
	}

	public void destroy() 
	{
	
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String url = request.getServletPath();
		String targetUrl = "";
		 MobileService mser = new  MobileServiceImpl();
		switch(url)
		{
		case "/home":
			try 
			{
				List<Mobile> mobList = mser.getAllMob();
				request.setAttribute("mobList", mobList);
				targetUrl = "Home.jsp";
			} 
			catch (MobileException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
		break;
		case "/buy":
			int mobId=Integer.parseInt(request.getParameter("mobId"));
			
			try 
			{
				mob = mser.getMobile(mobId);
				HttpSession sess = request.getSession(true);
				sess.setAttribute("mob", mob);
				targetUrl="Insert.jsp";
			} 
			catch (MobileException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
		break;
		case "/purchase":
			PurchaseDetails purchase = new PurchaseDetails();
			//purchase = mser.addPurchaseDetails(purchase);
			purchase.setCustName(request.getParameter("cname"));
			purchase.setMailId(request.getParameter("mail"));
			purchase.setPhoneNo(request.getParameter("phoneNo"));
			String dateStr = request.getParameter("pDate");
			DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			purchase.setPurchaseDate(LocalDate.parse(dateStr,format));
			purchase.setMobileId(mob.getMobId());
			
			HttpSession sess = request.getSession(false);
			mob=(Mobile)sess.getAttribute("mob");
			purchase.setMobileId(mob.getMobId());
			try 
			{
				mser.addPurchaseDetails(purchase);
				request.setAttribute("purchase", purchase);
				targetUrl="Success.jsp";
			} 
			catch (MobileException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
		break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
