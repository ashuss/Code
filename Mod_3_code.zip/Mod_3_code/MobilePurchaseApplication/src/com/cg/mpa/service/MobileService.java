package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public interface MobileService 
{
	List<Mobile> getAllMob() throws MobileException;
	Mobile getMobile(int mobId) throws MobileException;
	int addPurchaseDetails(PurchaseDetails purchase) throws MobileException;
}
