package com.cg.mpa.util;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.mpa.exception.MobileException;
//DSN is not working in this system....

public class DBUtil 
{
	public static Connection getCon()
		throws MobileException
		{
			Connection con = null;
			InitialContext context;
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
				con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
				/*context = new InitialContext();
				DataSource ds = (DataSource)context.lookup("java:/jdbc/OracleDS");
				con = ds.getConnection();*/
			}
			 catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(con);
			return con;
		}

}
