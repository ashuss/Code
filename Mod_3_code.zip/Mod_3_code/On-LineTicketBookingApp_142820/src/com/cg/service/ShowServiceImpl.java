package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.ShowDao;
import com.cg.dao.ShowDaoImpl;
import com.cg.dto.ShowDetails;
import com.cg.exception.BookingException;

public class ShowServiceImpl implements ShowService
{
	ShowDao sdao=new ShowDaoImpl();
	@Override
	public ArrayList<ShowDetails> getShowDetails() throws BookingException 
	{
		return sdao.getShowDetails();
	}
	@Override
	public ShowDetails getShowDetail(String showid) throws BookingException 
	{
		
		return sdao.getShowDetail(showid);
	}
	@Override
	public int updateShowDetails(int seats, String showname)
			throws BookingException
	{
		return sdao.updateShowDetails(seats,showname);
	}

	

}
