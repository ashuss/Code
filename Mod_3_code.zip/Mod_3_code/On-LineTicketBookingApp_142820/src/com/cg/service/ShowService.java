package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.ShowDetails;
import com.cg.exception.BookingException;

public interface ShowService
{
	ArrayList<ShowDetails> getShowDetails() throws BookingException ;
	public ShowDetails getShowDetail(String showid) throws BookingException ;
	public int updateShowDetails(int seats , String showname) throws BookingException ;
}
