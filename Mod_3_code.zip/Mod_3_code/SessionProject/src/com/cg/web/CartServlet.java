//adding book to session and retrieve
package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    
    public CartServlet() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		PrintWriter pw = response.getWriter();
		String book = request.getParameter("txtBook");
		HttpSession session = request.getSession(true); // checking session present or not if not existing create new session
		
		ArrayList<String> bookList = (ArrayList)session.getAttribute("BookListObj");
		
		if(bookList == null) //first time 
		{
			bookList = new ArrayList<String>();
			bookList.add(book);
			session.setAttribute("BookListObj", bookList); //keyName,value
		}
		else //second time
		{
			bookList.add(book);
			session.setAttribute("BookListObj", bookList);
		}
		pw.println("It is a new Session? : "+session.isNew());
		pw.println("Session id : "+session.getId());
		pw.println("Max Interval : "+session.getMaxInactiveInterval());
		pw.println("<hr/>");
		pw.println("Items in cart : "+bookList);
		pw.println("<br/>Do you Want to Purchase again?");
		pw.println("<a href = '/SessionProject/BookCatalogServlet'>Go To Book Catalog</a>");
	}

}
