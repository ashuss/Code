package com.cg.stock.dao;

import java.util.List;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.stock.dto.Order;
import com.cg.stock.dto.Stock;
@Repository("sDao")
public class StockDaoImpl implements IStockDao
{
	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public void addOrder(Order order) 
	{
		entitymanager.persist(order);
		entitymanager.flush();
		
	}

	@Override
	public List<Stock> showStockByName(String name) 
	{
		Query queryOne=entitymanager.createQuery("Select s FROM Stock s WHERE stock=:sName");
		queryOne.setParameter("sName", name);
		List<Stock> myList=queryOne.getResultList();
	    return myList;
	}

	@Override
	public List<Stock> showAllStock() 
	{
		Query queryTwo=entitymanager.createQuery("FROM Stock");
		List<Stock> myList1=queryTwo.getResultList();
		return myList1;
	}

}
