package com.cg.stock.service;

import java.util.List;

import com.cg.stock.dto.Order;
import com.cg.stock.dto.Stock;

public interface IStockService 
{
	public void addOrder(Order order);
	public List<Stock> showStockByName(String name);
	public List<Stock> showAllStock();
}
