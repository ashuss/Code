package com.cg.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.stock.dao.IStockDao;
import com.cg.stock.dto.Order;
import com.cg.stock.dto.Stock;
@Service("sService")
public class StockServiceImpl implements IStockService
{
	@Autowired
	IStockDao sDao;
	
	@Override
	public void addOrder(Order order) 
	{
		sDao.addOrder(order);
		
	}

	@Override
	public List<Stock> showStockByName(String name) 
	{
		return sDao.showStockByName(name);
	}

	@Override
	public List<Stock> showAllStock() 
	{
		return sDao.showAllStock();
	}

}
