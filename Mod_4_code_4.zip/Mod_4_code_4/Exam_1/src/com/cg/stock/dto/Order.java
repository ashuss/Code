package com.cg.stock.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="order_master")
public class Order 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="stock_id_seq")
	@SequenceGenerator(name="stock_id_seq",sequenceName="stock_seq")
	@Column(name="order_id")
	private Integer orderId;
	
	private String stock;
	
	private Double quote;
	
	@Column(name="order_amount")
	private Double orderAmt;
	
	@Column(name="commision")
	private Double comm;

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public Double getQuote() {
		return quote;
	}

	public void setQuote(Double quote) {
		this.quote = quote;
	}

	public Double getOrderAmt() {
		return orderAmt;
	}

	public void setOrderAmt(Double orderAmt) {
		this.orderAmt = orderAmt;
	}

	public Double getComm() {
		return comm;
	}

	public void setComm(Double comm) {
		this.comm = comm;
	}
	
	
	
}
