import java.io.IOException;

public class ThrowsDemo 
{
	public void method1() throws IOException
	{
		System.out.println("Inside method 1");
		method2();
	}
	
	public void method2() throws IOException
	{
		System.out.println("Inside method 2");
		throw new IOException();
	}
	
	
	
}
