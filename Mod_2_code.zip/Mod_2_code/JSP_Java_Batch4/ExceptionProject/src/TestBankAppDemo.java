import java.util.Scanner;


public class TestBankAppDemo 
{

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int currentBalance = 60000;
		
		System.out.println("Enter withdraw Amount: ");
		int withdrawAmt = sc.nextInt();
		
		if(withdrawAmt < currentBalance)
		{
			System.out.println("Ok have Sufficient balance you can withdraw.");
		}
		else
		{
			try
			{
				throw new LowBalaceException("Please Check balance of your account");
			}
			catch(LowBalaceException e)
			{
				System.out.println("Insufficient balance in your account. "+e.getMessage());
			}
		}
	}

}
