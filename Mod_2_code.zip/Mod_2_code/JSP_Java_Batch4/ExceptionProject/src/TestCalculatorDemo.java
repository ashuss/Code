import java.time.LocalDate;
import java.util.Scanner;
class Calculator
{
	int num1;
	int num2;
	int num[];
	public Calculator()
	{
	}
	public Calculator(int num1,int num2)
	{
		this.num1=num1;
		this.num2=num2;
	}
	
	public int doDivision()
	{
		float result=0.0F;
		try
		{
			//System.out.println("3rd Location of"+" Nums"+" is "+num[3]); //error bcz 3rd location dnt have any data
			result = num[0]/num[1];
		}
		catch(ArithmeticException ae)
		{
			System.out.println("Please check the divisor "+ae.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("This block is always executed whether the exception occurs"+
		"or do not occurs in the program.");
		}
		return (int)result;
	}
}

public class TestCalculatorDemo 
{

	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Num1: ");
		int num1 = sc.nextInt();
		System.out.println("Enter Num2: ");
		int num2 = sc.nextInt();
		Calculator cc = new Calculator();
		System.out.println("Division of 2 Numbers id: "+cc.doDivision());
		LocalDate today = null;
		System.out.println("Today is : "+LocalDate.now());
		

	}

}
