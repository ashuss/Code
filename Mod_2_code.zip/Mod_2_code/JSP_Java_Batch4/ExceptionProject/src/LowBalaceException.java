
public class LowBalaceException extends RuntimeException
{
	public LowBalaceException(String msg)
	{
		super(msg);
	}
	
}
