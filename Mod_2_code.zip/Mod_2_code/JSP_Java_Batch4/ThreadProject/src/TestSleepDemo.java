
public class TestSleepDemo 
{
	static Thread t1, t2 = null;

	public static void main(String[] args) 
	{
		System.out.println("Main Thread start Here");
		 MyThread obj1 = new MyThread("Welcome");
		 MyThread obj2 = new MyThread("Capgemini");
		 
		 t1 = new Thread(obj1);
		 t2 = new Thread(obj2);
		
		t1.start();
		t2.start();
		
		try 
		{
			t1.join();
			t2.join();
		} 
		catch (InterruptedException e1) 
		{
			
			e1.printStackTrace();
		}
		
		Thread currThread = Thread.currentThread();
		String threadName = currThread.getName();
		int threadPrio = currThread.getPriority();
	
		
		for(int i=1;i<5;i++)
		{
			System.out.println(threadName+" has priority of : "+threadPrio+" i = "+i);
			try
			{
				Thread.sleep(500);
		}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		System.out.println("Main Thread End Here");
	}

}
