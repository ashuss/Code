public class TestInheritanceDemo {

	public static void main(String[] args) 
	{
		Employee ashwini = new Employee(111,"Ashwini S",25000.0F);
		WageEmp preeta = new WageEmp(222,"Preeta A",5000.0F,5,50);
		SalesManager karan = new SalesManager(333,"Karan L",6000.0F,5,400,50, 9500);
		
		
		System.out.println("Employee Info: "+ashwini.dispEmpInfo());
		System.out.println("Emp Monthly Salary: " +ashwini.calcEmpBasicSal());
		System.out.println("Emp Annual Salary: " +ashwini.calcEmpAnnualSal());

		System.out.println("************************************************************");
		
		System.out.println("WageEmp Info: "+preeta.dispEmpInfo());
		System.out.println("Emp Monthly Salary: " +preeta.calcEmpBasicSal());
		System.out.println("Emp Annual Salary: " +preeta.calcEmpAnnualSal());
	
		System.out.println("*************************************************************");
		
		System.out.println("Sales Manager Info: "+karan.dispEmpInfo());
		System.out.println("Emp Monthly Salary: " +karan.calcEmpBasicSal());
		System.out.println("Emp Annual Salary: " +karan.calcEmpAnnualSal());
		
		
	}

}
