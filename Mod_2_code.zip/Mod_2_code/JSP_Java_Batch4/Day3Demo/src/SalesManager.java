
public class SalesManager extends WageEmp
{
	private int sale;
	private int comm;
	
	public SalesManager()
	{
		super();
	}
	
	public SalesManager(int empId, String empName, float empSal, int noOfHrs, int ratePerHrs,int sale, int comm)
	{
		super(empId,empName,empSal,noOfHrs,ratePerHrs);
		this.sale=sale;
		this.comm=comm;
	}
	
	public float calcEmpBasicSal()
	{
		return (super.calcEmpBasicSal()+(sale*comm));
	}
	
	public float calcEmpAnnualSal()
	{
		return calcEmpBasicSal()*12;
	}
}
