public class TestStaticEmpDemo 
{
	static
	{
		System.out.println("This is TestStatic empCount Static block");
	}
	public static void main(String[] args) 
	{
		Emp e1= new Emp(111,"Ashwini",1000.0F);
		Emp e2= new Emp(222,"Rahul",2000.0F);
		Emp e3= new Emp(333,"Rohit",3000.0F);
		
		System.out.println("Main Start Here");
		System.out.println(e1.dispEmpInfo());
		System.out.println(e2.dispEmpInfo());
		System.out.println(e3.dispEmpInfo());
		Emp.getCount();
		show();
	}
	private static void show()
	{
		System.out.println("Hi.....");
	}
}
