public class Emp
{
    private int EmpId;
    private String empName;
    private float empSal;
    static int empCount;
    
    static
    {
    	System.out.println("Emp Static block: ");
    	empCount=5;
    }
    
    public int getEmpId() 
    {
        return EmpId;
    }
    public void setEmpId(int empId) 
    {
        EmpId = empId;
    }
    public String getEmpName() 
    {
        return empName;
    }
    public void setEmpName(String empName) 
    {
        this.empName = empName;
    }
    public float getEmpSal() 
    {
        return empSal;
    }
    public void setEmpSal(float empSal) 
    {
        this.empSal = empSal;
    }
    public Emp() 
    {
        
    }
    public Emp(int empId, String empName, float empSal) {
        super();
        EmpId = empId;
        this.empName = empName;
        this.empSal = empSal;
        empCount++;
    }
    public String dispEmpInfo() 
    {
        return "Emp [EmpId=" + EmpId + ", empName=" + empName + ", empSal="
                + empSal + "]";
    }
    
    public static void getCount()
    {
        System.out.println("Emp Count Is : " +empCount);
    }
}
