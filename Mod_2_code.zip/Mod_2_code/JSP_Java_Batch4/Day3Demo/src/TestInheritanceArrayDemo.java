import java.util.Scanner;
public class TestInheritanceArrayDemo {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);		//sc variable for scanner
		System.out.println("How Many Employee? ");	//count of employees
		int empCount = sc.nextInt();
		Employee empArr[] = new Employee[empCount];	//Array of empArr of count given by user
		int eId=0;				//Local varibales initialization
		String enm="null";
		float esl=0.0F;
		int noOfHrs=0;
		int ratePerHrs=0;
		
		
		for(int i=0;i<empArr.length;i++)	//for loop
		{
			System.out.println("Enter Emp Id: ");	//for n number of employees inputs
			eId = sc.nextInt();
			System.out.println("Enter Emp Name: ");
			enm = sc.next();
			System.out.println("Enter Emp Salary: ");
			esl = sc.nextFloat();
			
			System.out.println("What type of Emp you Want? "+"1:Emp\t2:Wage Emp\t3:Sales Manager");
			System.out.println("Enter Choice?");
			int choice = sc.nextInt();	//Choice of employees

			switch(choice)	//switch case
			{
				case 1: empArr[i]= new Employee(eId,enm,esl);	//Employee
				break;
			
				case 2: System.out.println("Enter No of Hrs You worked: ");	//WageEmp
						noOfHrs = sc.nextInt();
						System.out.println("Enter Rate Per Hour: ");
						ratePerHrs = sc.nextInt();
						empArr[i]=new WageEmp(eId,enm,esl,noOfHrs,ratePerHrs);
				break;
			
				default:
					System.out.println("Enter No of Hrs You worked: ");	//WageEmp
					noOfHrs = sc.nextInt();
					System.out.println("Enter Rate Per Hour: ");
					ratePerHrs = sc.nextInt();
					System.out.println("Enter Sales you have done: ");	//Sales Manager(default)
					int sale = sc.nextInt();
					System.out.println("Commisions: ");
					int comm = sc.nextInt();
					empArr[i]=new SalesManager(eId,enm,esl,noOfHrs,ratePerHrs,sale,comm);
				break;	
			}
			
		}
		System.out.println("***********************************");
		
		for(int j=0;j<empArr.length;j++)
		{
			if(empArr[j] instanceof SalesManager)
			{
				System.out.println("Sales Manager: "+empArr[j].dispEmpInfo()+
						" Monthly Basic Salary: "+empArr[j].calcEmpBasicSal()+
						" Annual Salary: "+empArr[j].calcEmpAnnualSal());
			}
			else if(empArr[j] instanceof WageEmp)
			{
				System.out.println("Wage Emp: "+empArr[j].dispEmpInfo()+
						" Monthly Basic Salary: "+empArr[j].calcEmpBasicSal()+
						" Annual Salary: "+empArr[j].calcEmpAnnualSal());
			}
			else
			{
				System.out.println("Emp: "+empArr[j].dispEmpInfo()+
						" Monthly Basic Salary: "+empArr[j].calcEmpBasicSal()+
						" Annual Salary: "+empArr[j].calcEmpAnnualSal());
			}
		}

	}

}
