package com.cg.empmgm.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;
import com.cg.empmgm.service.EmpService;
import com.cg.empmgm.service.EmpServiceImpl;
public class EmpClient 
{
	static Scanner sc = null;
	static EmpService empSer = null;
	public static void main(String[] args) 
	{
		empSer = new EmpServiceImpl();
		sc = new Scanner(System.in);
		int choice = 0 ;
		
		while(true)
		{
			System.out.println("What Do You Want To Do?");
			System.out.println("******");
			System.out.println("1:Add\t 2:Fetch all Emp\t 3:Delete Emp\t 4:Update Emp\t 5:Exit");
			System.out.println("***");
			choice = sc.nextInt();
			System.out.println("***");
			switch(choice)
			{
			case 1: 
				insertEmp();
				break;
				
			case 2:
				fetchAllEmp();
				break;
				
			case 3:
				deleteEmp();
				break;
				
			case 4:
				updateEmp();
				break;
				
			default:
				System.exit(0);
			}
		}

	}
	
	/**********************main ends here************************/


public static void insertEmp()
{
	System.out.println("Enter EmpName: ");
	String enm = sc.next();
	float esl = 0.0F;
	try {
		if(empSer.validateName(enm))
		{
			System.out.println("Enter Salary: ");
			esl=sc.nextFloat();
			Employee ee =new Employee();
			ee.setEmpname(enm);
			ee.setEmpSal(esl);
			int dataAdded = empSer.addEmp(ee);
			if(dataAdded == 1)
			{
				System.out.println("Emp Data Added: ");
			}
			else
			{
				System.out.println("May be Some Exception while addition");
			}
		}
	} 
	catch (EmployeeException e) {
		
		System.out.println(e.getMessage());
	}
	
}
/**************************************/

public static void fetchAllEmp()
{
	try 
	{
		ArrayList<Employee> empList = empSer.getAllEmp();
		for(Employee ee:empList)
		{
			System.out.println(ee);
		}
			
	} 
	catch (EmployeeException e) 
	{
		System.out.println("Some exception while fetching data");
		e.printStackTrace();
	}

}
/**************************************/

public static void deleteEmp()
{
	System.out.println("Enter EmpId: ");
	int eid = sc.nextInt();
	
	try {
		if(empSer.validateDigit(eid))
		{
			
			int dataDeleted = empSer.deleteEmp(eid);
			if(dataDeleted == 1)
			{
				System.out.println("Emp Data Deleted: ");
			}
			else
			{
				System.out.println("May be Some Exception while deletion");
			}
		}
	} 
	catch (EmployeeException e) {
		
		System.out.println(e.getMessage());
	}
	
	
}
/**************************************/

public static void updateEmp()
{
	System.out.println("Enter EmpId: ");
	int eid = sc.nextInt();
	
	try {
		if(empSer.validateDigit(eid))
		{
			
			int dataUpdated = empSer.updateEmp(eid);
			if(dataUpdated == 1)
			{
				System.out.println("Emp Data Updated: ");
			}
			else
			{
				System.out.println("May be Some Exception while deletion");
			}
		}
	} 
	catch (EmployeeException e) {
		
		System.out.println(e.getMessage());
	}

	
}
}
