package com.cg.mobmgm.dao;

import java.util.ArrayList;

import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.exception.EmployeeException;

public interface MobDao 
{
	public int addMob(Mobile mobData) throws 
    EmployeeException;
	
	public ArrayList<Mobile> getAllMob() throws 
	EmployeeException;
    
    public int deleteMob(int mob_id)throws 
    EmployeeException;

	public Object searchMobile(float min, float max)throws 
    EmployeeException;

	public Object fetchAllMobile() throws 
    EmployeeException;
}
