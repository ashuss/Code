package com.cg.mobmgm.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.cg.mobmgm.util.DBUtil;
import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.exception.EmployeeException;

public class PurchaseDaoImpl implements PurchaseDao
{
	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    
	@Override
	public int addCust(PurchaseDetails purData) throws EmployeeException 
	{
		String insertQry = "INSERT INTO purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) VALUES(?,?,?,?,sysdate,?)";
   	 	int dataAdded =0;
   	 	PurchaseDetails pur = new PurchaseDetails();
   	 	
   	try 
   	{
			con = DBUtil.getCon();
			pst = con.prepareStatement(insertQry);
			pst.setInt(1, generatePurchaseId());
			pst.setString(2, pur.getcName());
			pst.setString(3, pur.getMailId());
			pst.setLong(4, pur.getPhoneNo());
			pst.setInt(5, pur.getMobId());
			dataAdded = pst.executeUpdate();
			
		} 
   	catch (Exception e) 
   	{
   		throw new 
           EmployeeException(e.getMessage());
		} 
   	finally
   	{
   		
   		try 
   		{
   			pst.close();
				con.close();
			} catch (SQLException e) 
   		{
				throw new EmployeeException(e.getMessage());
				//e.printStackTrace();
			}
   	}
		return dataAdded;
		
	}

	

	@Override
	public int generatePurchaseId() throws EmployeeException {
		String qry = "SELECT pur_seqq.NEXTVAL FROM DUAL";
    	int generatedVal;
        try 
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(qry);
            rs.next();
            generatedVal = rs.getInt(1);
        } 
        catch (Exception e) 
        {
            throw new 
            EmployeeException(e.getMessage());
        }
        finally
        {
            try
            {
            	rs.close();
            	st.close();
            	con.close();
            }
            catch(SQLException e)
            {
            	throw new
            	EmployeeException(e.getMessage());
            }
        }
        return generatedVal;
	}



	
	
}
