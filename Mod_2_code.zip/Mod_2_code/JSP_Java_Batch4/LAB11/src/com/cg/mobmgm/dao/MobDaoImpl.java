package com.cg.mobmgm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.exception.EmployeeException;
import com.cg.mobmgm.util.DBUtil;

public class MobDaoImpl implements MobDao 
{
	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    
	@Override
	public int addMob(Mobile mobData) throws EmployeeException 
	{
		String insertQry = "INSERT INTO mobiles(mobileid,name,price,quantity) VALUES(?,?,?,?)";
   	 	int dataAdded =0;
   	 	Mobile mob = new Mobile();
   	 
   	try 
   	{
			con = DBUtil.getCon();
			pst = con.prepareStatement(insertQry);
			
			pst.setInt(1, mob.getMobId());
			pst.setString(2,mob.getMobName());
			pst.setFloat(3, mob.getMobPrice());
			pst.setInt(4, mob.getMobQty());
			
			dataAdded = pst.executeUpdate();
			
		} 
   	catch (Exception e) 
   	{
   		throw new 
           EmployeeException(e.getMessage());
		} 
   	finally
   	{
   		
   		try 
   		{
   			pst.close();
				con.close();
			} catch (SQLException e) 
   		{
				throw new EmployeeException(e.getMessage());
				//e.printStackTrace();
			}
   	}
		return dataAdded;
		
	}

	
	
	@Override
    public ArrayList<Mobile> getAllMob() throws EmployeeException
    {
    	ArrayList<Mobile> mobList = new ArrayList<Mobile>();
    	String selectQry = "SELECT * FROM mobiles";
    	Mobile mb = null;
    	try 
    	{
			con = DBUtil.getCon();
			st=con.createStatement();
			rs = st.executeQuery(selectQry);
			while(rs.next())
			{
				mb = new Mobile(rs.getInt("mobileid"),
						rs.getString("name"),
						rs.getFloat("price"),
						rs.getInt("quantity"));
				mobList.add(mb);
			}
			
		}
    	catch (Exception e) 
    	{
    		throw new 
            EmployeeException(e.getMessage());
		} 
    	finally
    	{
    		
    		try 
    		{
    			rs.close();
    			st.close();
				con.close();
			} catch (SQLException e) 
    		{
				throw new 
	            EmployeeException(e.getMessage());
			}
    	}
        return mobList;
    }
	
	
	
	@Override
	public int deleteMob(int mob_id) throws EmployeeException {
		String insertQry = "DELETE FROM mobiles WHERE mobileid = ?";
	   	 int dataDeleted =0;
	   	
	   	 
	   	try 
	   	{
				con = DBUtil.getCon();
				pst = con.prepareStatement(insertQry);
				pst.setInt(1, mob_id);
				dataDeleted = pst.executeUpdate();
				
			} 
	   	catch (Exception e) 
	   	{
	   		throw new 
	           EmployeeException(e.getMessage());
			} 
	   	finally
	   	{
	   		
	   		try 
	   		{
	   			pst.close();
					con.close();
				} catch (SQLException e) 
	   		{
					throw new EmployeeException(e.getMessage());
					//e.printStackTrace();
				}
	   	}
			return dataDeleted;
	}
	
	
}
