package com.cg.mobmgm.dao;

import java.util.ArrayList;

import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.exception.EmployeeException;

public interface PurchaseDao 
{
	
   
    public int generatePurchaseId()throws 
    EmployeeException;

	public int addCust(PurchaseDetails purData) 
	throws EmployeeException;

	

}
