package com.cg.mobmgm.util;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.EmptyStackException;
import java.util.Properties;

import com.cg.mobmgm.exception.EmployeeException;


public class DBUtil 		//connection Object With Oracle Database
{
	static String dbunm = null;
	static String dbpwd = null;
	static String url = null;
	public static Connection getCon() throws IOException,EmptyStackException,SQLException,Exception
	{
		//return connection objects
		Connection con =null;
		Properties dbInfoProps = DBUtil.getProp();
		
		url = dbInfoProps.getProperty("dbURL");
		dbunm = dbInfoProps.getProperty("dbUser");
		dbpwd = dbInfoProps.getProperty("dbPwd");
		
		
		if(con == null)
		{
			con = DriverManager.getConnection(url, dbunm, dbpwd);
		}
		return con;
		
	}
	
	public static Properties getProp()		//return properties object
	throws EmptyStackException, IOException
	{
		Properties props = null;
		FileReader fr = null;
		props = new Properties();
		fr = new FileReader("resources/dbInfo.properties");		//foldername/filename
			props.load(fr);
		
		
		return props;
	}
}
