package com.cg.mobmgm.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.dao.MobDao;
import com.cg.mobmgm.dao.MobDaoImpl;
import com.cg.mobmgm.dao.PurchaseDao;
import com.cg.mobmgm.dao.PurchaseDaoImpl;
import com.cg.mobmgm.exception.EmployeeException;

public class MobileServiceImpl 
implements MobileService
{

	MobDao mbDao = null;
	PurchaseDao purDao = null;
	
	public  MobileServiceImpl()
	{
		mbDao = new MobDaoImpl();
		purDao = new PurchaseDaoImpl();
	}
		
		

	@Override
	public int addMob(Mobile mobData) throws EmployeeException {
		return mbDao.addMob(mobData);
	}

	@Override
	public ArrayList<Mobile> getAllMob() throws EmployeeException {
		return mbDao.getAllMob();
	}

	@Override
	public int deleteMob(int mob_id) throws EmployeeException {
		return mbDao.deleteMob(mob_id);
	}

	@Override
	public int addCust(PurchaseDetails purData) throws EmployeeException {
		return purDao.addCust(purData);
	}

	@Override
	public int generatePurchaseId() throws EmployeeException {
		return purDao.generatePurchaseId();
	}



	@Override
	public boolean validateName(String cust_name) throws EmployeeException 
	{
		String namePattern="[A-Z][A-Za-z]{2,10}";
		if(Pattern.matches(namePattern, cust_name))
		{
			return true;
		}
		else
		{
			throw new EmployeeException("Only Chars Allowed and starts with capital e.g Ashwini");
		}
	}

	@Override
	public boolean validatePhoneNo(long phoneNo) throws EmployeeException 
	{
		String numPattern = "[7-9]{1}[0-9]{9}";
		if(Pattern.matches(numPattern, new Long(phoneNo).toString()))
		{
			return true;
		}
		else
		{
			throw new EmployeeException("Mobile number contains 10 digits");
		}
	}

	@Override
	public boolean validateEmailId(String mail_id) throws EmployeeException 
	{
		String namePattern="[A-Za-z]+[@][A-Za-z]+[.][A-Za-z]";
		if(Pattern.matches(namePattern, mail_id))
		{
			return true;
		}
		else
		{
			throw new EmployeeException("Only Chars Allowed and starts with capital e.g Ashwini");
		}
		
	}

	@Override
	public boolean validateDigit(int mob_id) throws EmployeeException {
        String numPattern="[0-9]{4}";
        int flag=0;
        if(Pattern.matches(numPattern,new Integer(mob_id).toString()))
        {
            MobDao mobDao = null;
			ArrayList<Mobile> mobIdList=mobDao.getAllMob();
            for(Mobile tempMobIdList:mobIdList)
            {
                if (mob_id==tempMobIdList.getMobId())
                {
                    flag=1;
                }
            }
        }
        if (flag==1)
        {
            return true;
        }
        else
        {
            throw new EmployeeException("Only minimum 4 digits And From the List in Mobile ID");
        }



	}



	@Override
	public boolean validateDigit(Mobile mob_id) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}
}
