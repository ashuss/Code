package com.cg.mobmgm.junit;

import org.junit.Assert;
import org.junit.BeforeClass;


import org.junit.Test;

import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.dao.MobDao;
import com.cg.mobmgm.dao.MobDaoImpl;
import com.cg.mobmgm.exception.EmployeeException;

public class MobDaoImpTest 
{
	static MobDao mobDao = null;
    static Mobile mob = null;
    static int mobId = 1004;
    static float min = 3000;
    static float max = 40000;
    
    @BeforeClass
    public static void beforeClass() throws EmployeeException
    {
        mobDao = new MobDaoImpl();
        mob = new Mobile(1002,"Nokia Lumia 520",8000,20);
    }
    
    @Test
    public void testDeleteMob1() throws EmployeeException
    {
        Assert.assertEquals(0, mobDao.deleteMob(mobId));
    }
    
    @Test
    public void testFetchAllMob() throws EmployeeException
    {
        Assert.assertNotNull(mobDao.fetchAllMobile());
    }
    
    @Test
    public void testGetMobId() throws EmployeeException
    {
        Assert.assertNotNull(mobDao.fetchAllMobile());
    }
    
    @Test
    public void testSearchMob() throws EmployeeException
    {
        Assert.assertNotNull(mobDao.searchMobile(min, max));
    }

}
