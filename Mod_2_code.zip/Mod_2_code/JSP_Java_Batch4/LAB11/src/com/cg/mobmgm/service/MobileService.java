package com.cg.mobmgm.service;

import java.util.ArrayList;

import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.exception.EmployeeException;

public interface MobileService 
{
	public int addMob(Mobile mobData) throws 
    EmployeeException;
	
	public ArrayList<Mobile> getAllMob() throws 
	EmployeeException;
    
    public int deleteMob(int mob_id)throws 
    EmployeeException;
    
    public int addCust(PurchaseDetails purData) throws 
    EmployeeException;
   
    public int generatePurchaseId()throws 
    EmployeeException;
    
    public boolean validateDigit(Mobile mob_id)
    throws EmployeeException;
    	    
    public boolean validateName(String cust_name) 
    throws EmployeeException;
    
    public boolean validatePhoneNo(long phoneNo)
    throws EmployeeException;
    
    public boolean validateEmailId(String mail_id) 
    throws EmployeeException;

	boolean validateDigit(int mob_id) throws EmployeeException;
}
