package com.cg.mobmgm.ui;

import java.io.EOFException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;





import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.exception.EmployeeException;
import com.cg.mobmgm.service.MobileService;
import com.cg.mobmgm.service.MobileServiceImpl;


public class MobClient 
{
	static Scanner sc = null;
	static MobileService mobSer = null;
	public static void main(String[] args) 
	{
		mobSer = new MobileServiceImpl();
		sc = new Scanner(System.in);
		int choice = 0 ;
		
		while(true)
		{
			System.out.println("What Do You Want To Do?");
			System.out.println("1:Add\t 2:Display Data\t 3:Delete Emp\t 4:Exit");
			choice = sc.nextInt();
			System.out.println("***");
			switch(choice)
			{
			case 1: 
				insertMob();
				break;
				
			case 2:
				fetchAllMob();
				break;
				
			case 3:
				deleteMob();
				break;
				
			default:
				System.exit(0);
			}
		}
	}
	
	private static void deleteMob() {
		// TODO Auto-generated method stub
		
	}

	/**********************main ends here************************/
	
	
	
	public static void insertMob()
	{
		System.out.println("Enter Name : ");
		String cnm = sc.next();
		try {
			if(mobSer.validateName(cnm))
			{
				System.out.println("Enter Mail Id: ");
				String mid = sc.next();
				
				//if(purSer.validateEmailId(mid))
		 		//{
					System.out.println("Enter Phone No: ");
					long ph= sc.nextLong();
					
					if(mobSer.validatePhoneNo(ph))
					{
						System.out.println("Enter Mobile Id: ");
						int mobid= sc.nextInt();
						
						if(mobSer.validateDigit(mobid))
						{
							PurchaseDetails pd = new PurchaseDetails();
							pd.setcName(cnm);
							pd.setMailId(mid);
							pd.setPhoneNo(ph);
							pd.setMobId(mobid);
							int dataAdded = mobSer.addCust(pd);
							if(dataAdded == 1)
							{
								System.out.println("Customer Data Added: ");
							}
							else
							{
								System.out.println("May be Some Exception while addition");
							}
						}
					}
				}
			//}
		}
		 catch (Exception e) 
		{
				
				System.out.println(e.getMessage());
			}
	}			
	/**************************************/

	public static void fetchAllMob()
	{
		try 
        {
            ArrayList<Mobile> mobList=mobSer.getAllMob();
            for(Mobile ee:mobList) 
            {
                System.out.println(ee);
            }
        } 
        catch (EmployeeException e)
        {
            System.out.println("Some exception while fetching data");
            e.printStackTrace();
        }

	}
}
