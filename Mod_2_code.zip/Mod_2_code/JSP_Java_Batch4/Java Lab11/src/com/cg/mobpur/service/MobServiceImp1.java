package com.cg.mobpur.service;


import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.dao.MobDao;
import com.cg.mobpur.dao.MobDaoImpl;
import com.cg.mobpur.exception.MobileException;

public class MobServiceImp1 implements MobService 
{
	MobDao mobDao=null;
	public MobServiceImp1()
	{
		mobDao=new MobDaoImpl();
	}
	@Override
	public int addpurchasedetails(Purchase ps) throws MobileException {
		
		return mobDao.addpurchasedetails(ps);
	}

	@Override
	public int generatepurchaseId() throws MobileException {
		
		return mobDao.generatepurchaseId();
	}

	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException {
		
		return mobDao.getAllMob();
	}
	@Override
	public ArrayList<Integer> generateMobId() throws MobileException {
		
		return mobDao.generateMobId();
	}
	@Override
	public boolean validateMobileId(int MobileId) throws MobileException
	{
		  mobDao = new MobDaoImpl();
	        String midPattern="[0-9]{4}$";
	        ArrayList<Integer>mobList=mobDao.generateMobId();
	        String mob=String.valueOf(MobileId);
	        if(Pattern.matches(midPattern,mob))
	        {
	            for(Integer i:mobList)
	            {
	                if(MobileId==i)
	                {
	                    return true;
	                }
	            }
	        }
	    return false;
	            }
	           
	@Override
	public boolean validateName(String CustomerName) throws MobileException 
	{
		
		String namePattern="[A-Z][a-z]{1,19}$";
        if(Pattern.matches(namePattern, CustomerName))
        {
            return true;
        }
        else
        {
            throw new MobileException("Only Alpthabets are allowed and starts with capital...(Ex:Vardhani)...Max 20 characters");
        }
    }
	@Override
	public boolean validatePhoneNo(long phoneNo) throws MobileException 
	{
		
		String numPattern="[0-9]{10}";
		if(Pattern.matches(numPattern, new Long(phoneNo).toString()))
				{
			return true;
				}
		else
		{
            throw new MobileException("Invalid Phone NO");
        }
	}

	@Override
	public boolean validateMailId(String mailid) throws MobileException 
	{
		
		  String mailPattern="[a-z]+[@][a-z]{5}[.][a-z]{1,3}";
	        if(Pattern.matches(mailPattern, mailid))
	        {
	            return true;
	        }
	        else
	        {
	            throw new MobileException("Invalid Mail Id");
	        }
	}
	@Override
	public boolean validategenerateMobQuantity(Purchase ps) throws MobileException {
		
		mobDao = new MobDaoImpl();
        int quantity=mobDao.generateMobQuantity(ps);
        if(quantity>0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
	@Override
	public int updateQuantity(int mobileId) throws MobileException
	{
		return mobDao.updateQuantity(mobileId);
	}
	@Override
	public int deleteMobiles(int mobileId) throws MobileException {
		return mobDao.deleteMobiles(mobileId);
	
	}
	@Override
	public ArrayList<Mobile> getMobilesInRange(float min, float max)
			throws MobileException {
		return mobDao.getMobilesInRange(min,max);
		
	}
	}
	