package com.cg.mobpur.service;

import java.util.ArrayList;

import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;

public interface MobService 
{
	public int addpurchasedetails(Purchase ps)throws MobileException;
	public int generatepurchaseId()throws MobileException;
	public int updateQuantity(int mobileId) throws MobileException;
	public int deleteMobiles(int mobileId) throws MobileException;
	public ArrayList<Mobile>getMobilesInRange(float min, float max)throws MobileException;
	public ArrayList<Mobile>getAllMob()throws MobileException;
	public ArrayList<Integer>generateMobId()throws MobileException;
	
	
	public boolean validategenerateMobQuantity(Purchase ps)
			throws MobileException;
	
	public boolean validateMobileId(int MobileId)
			throws MobileException;
	
	public boolean validateName(String CustomerName)
			throws MobileException;
	
	public boolean validatePhoneNo(long phoneNo)
			throws MobileException;
	
	public boolean validateMailId(String mailid)
			throws MobileException;
	
}
