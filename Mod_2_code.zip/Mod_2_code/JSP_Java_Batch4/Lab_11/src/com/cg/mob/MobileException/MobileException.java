package com.cg.mob.MobileException;

public class MobileException extends Exception
{
    public MobileException(String msg)
    {
        super(msg);
    }
}
