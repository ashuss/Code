package com.cg.mob.dao;

import java.util.ArrayList;

import com.cg.mob.MobileException.MobileException;
import com.cg.mob.bean.Mobile;

public interface MobDao 
{
	public int addMob(Mobile mob) throws MobileException;
    public ArrayList<Mobile> getAllMob() throws MobileException;
    public int delMob(int mobid) throws MobileException;
    public int UpdateMobQty(int mobid) throws MobileException;
    public ArrayList<Mobile> searchMobile(float min,float max) throws MobileException;

}
