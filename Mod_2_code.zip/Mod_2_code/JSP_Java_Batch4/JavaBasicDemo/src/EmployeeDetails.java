
public class EmployeeDetails {
	
	private int id;
	private String name;
	private float salary;
	private String gender; 
	


public void initEmployee()
{
	id=0;
	name=" ";
	salary=0;
	gender=" " ;		
}

public void setEmployee(int ID, String names, float sal, String gendr)
{
	id=ID;
	name=names;
	salary=sal;
	gender=gendr;
}
public String dispEmployee()
{
	return id+" "+name+" "+salary+" "+gender;
}

}