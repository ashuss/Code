public class TestStudentBeanDemo {

	public static void main(String[] args) 
	{
		Student s1=new Student();	//call constructor Student
		s1.setRollNo(111);			//set values for parameters
		s1.setStuName("Ashwini");
		s1.setMark(45);
		
		System.out.println("Roll No: "+s1.getRollNo());				//get values and display
		System.out.println("Student Name: "+s1.getStuName());
		System.out.println("Marks: "+s1.getMark());
		
		System.out.println("*****************************************");

		Student s2=new Student();
		s2.setRollNo(222);
		s2.setStuName("Rahul");
		s2.setMark(50);
		
		System.out.println("Roll No: "+s2.getRollNo());
		System.out.println("Student Name: "+s2.getStuName());
		System.out.println("Marks: "+s2.getMark());

		System.out.println("*****************************************");

	}

}
