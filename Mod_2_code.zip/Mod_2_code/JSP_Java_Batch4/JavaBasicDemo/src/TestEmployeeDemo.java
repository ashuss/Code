
public class TestEmployeeDemo {

	public static void main(String[] args) 
	{
		Employee e1=new Employee(1423021,"Ashwini Shedage",1000.0F,'F');
		
		Employee e2=new Employee(1423022,"Rahul Dhane",2000.0F,'M');
		
		Employee e3=new Employee(1423023,"Lalita Gawas",1500.0F,'F');
		
		System.out.println("Emp Info: " +e1.dispEmployee());
		
		System.out.println("Emp Info: " +e2.dispEmployee());
		
		System.out.println("Emp Info: " +e3.dispEmployee());
		
	}

}
