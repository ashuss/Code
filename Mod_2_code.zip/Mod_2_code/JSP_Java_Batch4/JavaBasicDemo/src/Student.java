public class Student 
{
	private int rollNo;
	private String stuName;
	private int mark;
	
	public Student()					//constructor
	{
		
	}
	
	public int getRollNo() 			//get function
	{
		return rollNo;
	}
	
	public String getStuName()
	{
		return stuName;
	}
	
	public int getMark()
	{
		return mark;
	}
	
	public void setRollNo(int rollNo)	 //set function
	{
		this.rollNo=rollNo;
	}
	
	public void setStuName(String stuName)
	{
		this.stuName=stuName;
	}
	
	public void setMark(int mark)
	{
		this.mark=mark;
	}
}
