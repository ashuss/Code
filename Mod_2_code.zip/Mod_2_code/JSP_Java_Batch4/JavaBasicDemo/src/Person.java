
public class Person 
{
	 private String firstName;
	 private String lastName;
	 private  char gender;
	 private int age;
	 private float weight;
	 
	 public Person()
	 {
	 	firstName = "null";
	 	lastName = "null";
	 	gender = ' ';
	 	age = 0;
	 	weight = 0.0F;
	 }
	 
	 public Person(String firstName, String lastName, char gender, int age, float weight)
	 {
	 	this.firstName=firstName;
	 	this.lastName=lastName;
	 	this.gender=gender;
	 	this.age=age;
	 	this.weight=weight;
	 }
	 
	 public String dispEmployee()
	 {
	 	System.out.println("Person Details");
	 	
	 	return 	"First Name = "+firstName+"\n Last Name= " +lastName
	 			+"\n Gender= "+gender
	 			+"\n age= "+age+"\n weight = "+weight;
	 }
}
