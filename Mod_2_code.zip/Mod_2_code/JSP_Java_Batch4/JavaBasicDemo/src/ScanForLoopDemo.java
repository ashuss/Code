import java.util.Scanner;
public class ScanForLoopDemo {
	
	public static void main(String args[]) 
	{
		
	
		Scanner sc = new Scanner(System.in);
		
		
		for(int i=0;i<3;i++)
		{
			System.out.println("Enter Name :");
			String name = sc.next();
			
			System.out.println("Enter Day :");
			int dayOfDoj = sc.nextInt();
			
			System.out.println("Enter Month :");
			int monthOfDoj = sc.nextInt();
			
			System.out.println("Enter Year :");
			int yearOfDoj = sc.nextInt();
			
			Date ashwiniDOJ = new Date(dayOfDoj, monthOfDoj, yearOfDoj);
			System.out.println(name+"'s DOJ :" +ashwiniDOJ.dispDate());
		}

		
	}

}
