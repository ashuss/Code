import java.util.Scanner;
public class EmployeeDetailsDemo {

	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		Employee allEmps[] = new Employee[3];
		int EmpId=0;
		String EmpName="unknwon";
		float Salary=0.0F;
		String Gen=" " ;
		
		for(int i=0;i<allEmps.length;i++)
		{
			System.out.println("Enter Name :");
			EmpName = sc.next();
			
			System.out.println("Enter Id :");
			EmpId= sc.nextInt();
			
			System.out.println("Enter Salary :");
			Salary = sc.nextFloat();
			
			System.out.println("Enter Gender :");
			Gen = sc.next();
			char Gender = Gen.charAt(0); 
			
			allEmps[i] = new Employee(EmpId, EmpName,Salary,Gender);
		}
		
		for(int j=0;j<allEmps.length;j++)
		{
			System.out.println(" Employee Details : "+allEmps[j].dispEmployee());
		}
	}

}
