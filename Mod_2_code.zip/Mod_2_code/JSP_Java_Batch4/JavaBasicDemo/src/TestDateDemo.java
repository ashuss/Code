
public class TestDateDemo {

	public static void main(String[] args) {
		
		Date ashuDOJ = new Date(13,12,2017);
	
		System.out.println("Ashu DOJ is: "+ashuDOJ.dispDate());
		
		Date rahulDOJ = new Date(31,12,2017);
		
		System.out.println("Rahul DOJ is: "+rahulDOJ.dispDate());
		
		Date unknownPerson = new Date();
		System.out.println("Unknown Person DOJ is: "+unknownPerson.dispDate());

	}

}
