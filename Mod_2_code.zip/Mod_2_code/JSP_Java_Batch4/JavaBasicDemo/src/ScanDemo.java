import java.util.Scanner;
public class ScanDemo {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Day :");
		int dayOfDoj = sc.nextInt();
		
		System.out.println("Enter Month :");
		int monthOfDoj = sc.nextInt();
		
		System.out.println("Enter Year :");
		int yearOfDoj = sc.nextInt();
		
		Date ashwiniDOJ = new Date(dayOfDoj, monthOfDoj, yearOfDoj);
		
		System.out.println("UR DOJ :" +ashwiniDOJ.dispDate());

	}

}
