
public class Employee {

	 private String EmpName;
	 private int  EmpId;
	 private float Salary;
	 private  char Gender;
	 private Date DOJ;


public Employee()
{
	EmpId=0;
	EmpName="UnKnown ";
	Salary=0.0F;
	Gender=' ' ;	
	DOJ= new Date();
	//System.out.println("Empty constructor called");
}

public Employee(int EmpId, String EmpName, float Salary, char Gender, Date DOJ)
{
	//this();
	this.EmpId=EmpId;
	this.EmpName=EmpName;
	this.Salary=Salary;
	this.Gender=Gender;
	this.DOJ=DOJ;
}
public String dispEmployee()
{
	return " Employee [Employee Id = "+EmpId+
			", Employee Name= "+EmpName
			+", Employee Salary= "+Salary
			+", Gender= "+Gender+",DOJ= "+DOJ.dispDate()+"]";
}
public float calcBasicSal()
{
	return Salary;
}
}
