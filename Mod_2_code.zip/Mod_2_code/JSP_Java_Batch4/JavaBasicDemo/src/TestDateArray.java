import java.util.Scanner;
public class TestDateArray {

	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		Date allDOJ[] = new Date[3];
		String names[] = new String[3];
		int day=0, month=0, year=0;
		
		for(int i=0;i<allDOJ.length;i++)
		{
			System.out.println("Enter Name :");
			names[i] = sc.next();
			
			System.out.println("Enter Day :");
			day = sc.nextInt();
			
			System.out.println("Enter Month :");
			month = sc.nextInt();
			
			System.out.println("Enter Year :");
			year = sc.nextInt();
			
			allDOJ[i] = new Date(day,month,year);
		}
		
		for(int j=0;j<allDOJ.length;j++)
		{
			System.out.println(names[j]+" DOJ : "+allDOJ[j].dispDate());
		}
	}

}
