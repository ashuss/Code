
public class TestSwitchDemo {

	public static void main(String args[]) {
		// TODO Auto-generated method stub
		int day=Integer.parseInt(args[0]);
		switch(day){
		case 6: System.out.println("Saturday");
		
		case 7: System.out.println("Sunday");
		
		default: System.out.println("Week Days");
		
		}
	}

}
