public class Medicine 
{
	protected String medName;
	protected String companyName;
	protected float  price;
	Date expDate;
	
	public Medicine() 
	{
	}
	
	public Medicine(String medName, String companyName, float price, Date expDate) 
	{
		this.medName = medName;
		this.companyName = companyName;
		this.price = price;
		this.expDate=expDate;
	}
	
	public String dispMedicineInfo() 
	{
		return "Medicine [medName=" + medName + ", companyName=" + companyName
				+ ", price=" + price + "expDate = "+expDate.dispDate()+"]";
	}
	
	
}
