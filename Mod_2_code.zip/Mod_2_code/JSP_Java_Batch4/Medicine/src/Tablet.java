
public class Tablet extends Medicine 
{
	
	
	public Tablet() 
	{
		super();	
	}

	public Tablet(String medName, String companyName, float price, Date ExpDate) 
	{
		super( medName,companyName, price, ExpDate);
		
	}
	
	public String dispMedicineInfo() 
	{
		
		return super.dispMedicineInfo()+" Store in Cool and Dry Place.";
	}
	
	
}
