import java.util.Scanner;
public class TestMedicine {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);	
		System.out.println("How many Medicines? ");
		int medCount = sc.nextInt();
		
		Medicine medArr[] = new Medicine[medCount];
		
		String medName="Null";
		String companyName="null";
		float  price=0.0F;
		Date expDate;
		int d=0, m=0, y=0;
		
		
		for(int i=0;i<medArr.length;i++)	//for loop
		{
			System.out.println("Enter Medicine Name: ");	//
			medName = sc.next();
			System.out.println("Enter Company Name: ");
			companyName = sc.next();
			System.out.println("Enter Price: ");
			price = sc.nextFloat();
			System.out.println("Enter Expiry Date = ");
			System.out.println("Enter day = ");
			d = sc.nextInt();
			System.out.println("Enter month = ");
			m = sc.nextInt();
			System.out.println("Enter year = ");
			y = sc.nextInt();
			expDate = new Date(d,m,y);
			
			System.out.println("What type of Medicine you Want? "+"1:Tablet\t2:Oinment\t3:Syrup");
			System.out.println("Enter Choice?");
			int choice = sc.nextInt();	

			switch(choice)	
			{
				case 1: 
						medArr[i]= new Tablet(medName,companyName, price, expDate);	
				break;
			
				case 2: 
						medArr[i]= new Oinment(medName,companyName, price, expDate);
				break;
			
				default:
						
						medArr[i]= new Syrup(medName,companyName, price, expDate);
				break;	
			}
			
		}
		
		System.out.println("***********************************");
		
		for(int j=0;j<medArr.length;j++)
		{
			if(medArr[j] instanceof Syrup)
			{
				System.out.println("Syrup: "+medArr[j].dispMedicineInfo()+
						" Description: "+medArr[j].dispMedicineInfo());
			}
			else if(medArr[j] instanceof Oinment)
			{
				System.out.println("Oinment: "+medArr[j].dispMedicineInfo()+
						" Description: "+medArr[j].dispMedicineInfo());
			}
			else
			{
				System.out.println("Tablet: "+medArr[j].dispMedicineInfo()+
						" Description: "+medArr[j].dispMedicineInfo());
			}
		}

	}

}
