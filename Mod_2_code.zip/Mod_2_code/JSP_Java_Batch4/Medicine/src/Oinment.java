
public class Oinment extends Medicine
{
	

	public Oinment() 
	{
		
	}

	public Oinment(String medName, String companyName, float price, Date expDate) 
	{
		super(medName, companyName, price, expDate);
	
	}
	
	public String dispMedicineInfo() 
	{
		return super.dispMedicineInfo()+ "For external use only.";
	}
	
}
