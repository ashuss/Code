public class Syrup extends Medicine
{
	

	public Syrup() 
	{
		super();
	}

	public Syrup(String medName, String companyName, float price, Date expDate) 
	{
		super(medName, companyName, price, expDate);
		
	}
	
	public String dispMedicineInfo() 
	{
		return super.dispMedicineInfo()+
				"Shake well before use.";
	}
	
	
}
