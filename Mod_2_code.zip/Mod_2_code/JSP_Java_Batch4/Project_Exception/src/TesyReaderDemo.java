import java.io.*;


public class TesyReaderDemo 
{

	public static void main(String[] args) 
	{
		FileReader fr = null;
		FileWriter fw = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		try
		{
			fr = new FileReader("MyDate.java");
			br = new BufferedReader(fr);
			fw = new FileWriter("Ashwini.txt");
			bw =new BufferedWriter(fw);
			
			String line = br.readLine();
			while(line != null)
			{
				bw.write(line);
				bw.newLine();
				bw.flush();
				line = br.readLine();
			}
			System.out.println("All data Written line bye line in the file");
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		
		

	}

}
