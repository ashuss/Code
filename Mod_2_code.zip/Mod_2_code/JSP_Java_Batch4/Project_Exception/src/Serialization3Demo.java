


	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.ObjectOutputStream;
	import java.util.Scanner;

	public class Serialization3Demo 
	{    
	
	    public static void main(String[] args)
	    {
	        Scanner sc = new Scanner(System.in);
	        Emp em[] = new Emp[3];
	        
	        
	        for(int i=0;i<3;i++)
	        {
	            System.out.println("Enter Employee "+(i+1)+" details:");
	            
	            System.out.println("Enter Emp ID");
	            int empId = sc.nextInt();
	            
	            System.out.println("Enter Emp Name");
	            String empName = sc.next();
	            
	            System.out.println("Enter Emp Salary");
	            float empSal = sc.nextFloat();
	            
	            em[i] = new Emp(empId,empName,empSal);
	        }
	        
	        FileOutputStream fos;
	        
	        try
	        {
	            fos = new FileOutputStream("3EmpData.obj");
	            ObjectOutputStream oos = new ObjectOutputStream(fos);
	            
	            for(int i=0;i<3;i++)
	            {
	                oos.writeObject(em[i]);
	            }
	            
	            System.out.println("Emp Object is written in a file");
	        }
	        
	        catch (FileNotFoundException e)
	        {
	            e.printStackTrace();
	        }
	        
	        catch (IOException e)
	        {
	            e.printStackTrace();
	        }
	        
	    }

	}




