import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestEmpFileDemo 
{

	public static void main(String[] args) 
	{
		try
		{
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			System.out.println("Enter Emp Id: ");
			int eid = Integer.parseInt(br.readLine());
			
			System.out.println("Enter Emp Name: ");
			String enm = br.readLine();
			
			System.out.println("Enter Emp Sal: ");
			float esl = Float.parseFloat(br.readLine());
			
			System.out.println(eid+"    "+enm+"     "+esl);
			FileWriter fw = new FileWriter("EmpInfo.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			Integer eIds = new Integer(eid); //boxing
			Float esls = new Float(esl);
			bw.write(eIds.toString());
			bw.write(enm);
			bw.write(esls.toString());
			bw.flush();
			System.out.println("Emp Info written in a file");
			
		}
		catch(IOException ie)
		{
			ie.printStackTrace();
		}
		
	}

}
