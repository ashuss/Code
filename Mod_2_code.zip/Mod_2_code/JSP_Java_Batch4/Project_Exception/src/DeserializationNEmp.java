import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Scanner;


public class DeserializationNEmp {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
        int num;
        System.out.println("Enter number of Employees:");
        num = sc.nextInt();
        Emp em[] = new Emp[num];
		FileInputStream fis;
		
		try
        {
            fis = new FileInputStream("NEmp.obj");
            ObjectInputStream ois = new ObjectInputStream(fis);

          for(int i=0;i<num;i++)
		{
					em[i] = (Emp)ois.readObject();
            		System.out.println(em[i]);
            		System.out.println("Emp Object is written in a file");
		}
            
        }
        catch (Exception e)
        {
            e.printStackTrace(); }
        }
}









