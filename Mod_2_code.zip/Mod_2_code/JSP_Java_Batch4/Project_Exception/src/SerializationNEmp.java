import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class SerializationNEmp    //n Employees
{

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int num;
        System.out.println("Enter number of Employees:");
        num = sc.nextInt();
        Emp emps[] = new Emp[num];
        
        
        for(int i=0;i<num;i++)
        {
            System.out.println("Enter Employee "+(i+1)+" details:");
            
            System.out.println("Enter Emp ID");
            int empId = sc.nextInt();
            
            System.out.println("Enter Emp Name");
            String empName = sc.next();
            
            System.out.println("Enter Emp Salary");
            float empSal = sc.nextFloat();
            
            emps[i] = new Emp(empId,empName,empSal);
        }
        
        FileOutputStream fos;
        
        try
        {
            fos = new FileOutputStream("NEmp.obj");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            for(int i=0;i<num;i++)
            {
                oos.writeObject(emps[i]);
            }
            
            System.out.println("Emp Object is written in a file");
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

}

