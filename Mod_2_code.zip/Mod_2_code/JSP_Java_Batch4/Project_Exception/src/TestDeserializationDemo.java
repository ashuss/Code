import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Scanner;


public class TestDeserializationDemo 
{

	public static void main(String[] args) 
	{
		
		Emp e1 = new Emp();
		FileInputStream fis;
		
		try
        {
            fis = new FileInputStream("EmpData.obj");
            ObjectInputStream ois = new ObjectInputStream(fis);
            e1 = (Emp)ois.readObject();
            System.out.println(e1);
            System.out.println("Emp Object is written in a file");
        }
        catch (Exception e)
        {
            e.printStackTrace(); }
        }

	}


