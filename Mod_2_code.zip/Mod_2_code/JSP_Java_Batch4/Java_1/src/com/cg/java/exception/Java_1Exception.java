package com.cg.java.exception;

public class Java_1Exception extends Exception
{

	public Java_1Exception(String msg)
	{
		super(msg);
	}
}
