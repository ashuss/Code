package com.cg.java.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.java.exception.Java_1Exception;



public class DBUtil 
{
	static String dbunm = null;
	static String dbpwd = null;
	static String url = null;
	public static Connection getCon() throws IOException,Java_1Exception,SQLException,Exception
	{
		//return connection objects
		Connection con =null;
		Properties dbInfoProps = DBUtil.getProp();
		
		url = dbInfoProps.getProperty("dbURL");
		dbunm = dbInfoProps.getProperty("dbUser");
		dbpwd = dbInfoProps.getProperty("dbPwd");
		
		
		if(con == null)
		{
			con = DriverManager.getConnection(url, dbunm, dbpwd);
		}
		return con;
		
	}
	
	public static Properties getProp()		//return properties object
	throws Java_1Exception, IOException
	{
		Properties props = null;
		FileReader fr = null;
		props = new Properties();
		fr = new FileReader("resources/dbInfo.properties");		//foldername/filename
			props.load(fr);
		
		
		return props;
	}
}
