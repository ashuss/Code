
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;


public class TestHashMapDemo 
{

	public static void main(String[] args) 
	{
		HashMap<Long,String> mobileDirectory = new HashMap<Long,String>();
		
		mobileDirectory.put(7506382849L, "Ashwini S");
		mobileDirectory.put(7506383849L, "Preeta A");
		mobileDirectory.put(7506384849L, "Karan L");
		mobileDirectory.put(7506385849L, "Rahul D");
		mobileDirectory.put(7506386849L, "Anjum F");
		
		Set<Entry<Long,String>> setIt = mobileDirectory.entrySet();
		
		Iterator<Entry<Long,String>> mobIt = setIt.iterator();
		
		while(mobIt.hasNext())
		{
			Entry<Long,String> dirEntry = mobIt.next();
			System.out.println("Mobile : "+dirEntry.getKey());
		}
		
	}

}
