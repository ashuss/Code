import java.util.ArrayList;
import java.util.Iterator;

public class TestEmpArrayListDemo
{

    public static void main(String[] args)
    {
        ArrayList<Emp> empList = new ArrayList<Emp>();
        
        Emp e1 = new Emp(101,"Abc",5000.0f);
        Emp e2 = new Emp(102,"ABc",4000.0f);
        Emp e3 = new Emp(103,"ABC",3000.0f);
        Emp e4 = new Emp(104,"Pqr",2000.0f);
        Emp e5 = new Emp(105,"PQr",1000.0f);
        
        empList.add(e1);
        empList.add(e2);
        empList.add(e3);
        empList.add(e4);
        empList.add(e5);
        
        System.out.println("Without Using Iterator");
        System.out.println(empList);
        
        System.out.println("Using Iterator");
        Iterator<Emp> empListIt = empList.iterator();
        while(empListIt.hasNext())
        {
            Emp tempEmp = empListIt.next();
            System.out.println(" ID : "+tempEmp.getEmpId());
            System.out.println(" Name : "+tempEmp.getEmpName());
            System.out.println(" Salary : "+tempEmp.getEmpSal());
            System.out.println("------------------------------------");
        }
    }

}

