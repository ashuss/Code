import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class TestDateDemos 
{

	public static void main(String[] args) 
	{
		LocalDate today = LocalDate.now();
		System.out.println("Today Date: "+today);
		
		System.out.println("************************");
		
		LocalDate myDOJ = LocalDate.of(2017, 12,13 );
		System.out.println("My Date of Join: "+myDOJ);
		
		System.out.println("******************************");

		String ashuDOJ = "13-Dec-2017";
		DateTimeFormatter myFormat = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate ashuDojD = LocalDate.parse(ashuDOJ,myFormat);
		System.out.println("Ashwini DOJ : "+ashuDojD);
		
		DateTimeFormatter secondFormat = DateTimeFormatter.ofPattern("yyyy-MMM-dd");
		String urDOJ = ashuDojD.format(secondFormat);
		System.out.println("........."+urDOJ);
		
		System.out.println("Difference");
		Period period = Period.between( myDOJ, today);
		int years = period.getYears();
		int month = period.getMonths();
		int day = period.getDays();
		
		System.out.println("My Exp In CG Is: "+years+ " Years "+month+" Months "+day+" Days");
	}
	

}
