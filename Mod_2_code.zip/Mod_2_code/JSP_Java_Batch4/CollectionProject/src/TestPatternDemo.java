import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestPatternDemo 
{

	public static void main(String[] args) 
	{
		String inputStr = "Test String";
		String patern = "Test String";
		boolean patternMatched = Pattern.matches(patern,inputStr);
		System.out.println(patternMatched);
		System.out.println("*******************************************");

	
	String input = "Shop,Mop,Hopping,Chopping";
	Pattern pattern = Pattern.compile("hop");
	Matcher matcher = pattern.matcher(input);
	//System.out.println(matcher.matches());
	while (matcher.find()) 
	{
		System.out.println(matcher.group() + ": " + matcher.start() + ": "
				+ matcher.end());
	}
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter your mobile No");
	String mobile = sc.next();
	String mobilePatter = "[7-9][0-9]{9}";
	
	if(Pattern.matches(mobilePatter, mobile))
	{
		System.out.println("Valid Mobile No");
	}
	else
	{
		System.out.println("Only 10 digits starts with 7 8 9 allowed");
	}
	}

}
