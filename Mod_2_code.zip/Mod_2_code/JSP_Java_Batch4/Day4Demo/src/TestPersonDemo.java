
public class TestPersonDemo 
{

	public static void main(String[] args) 
	{
		Person p1 = new Person("Ashwini S","PSYU8521",22);
		Person p2 = new Person("Preeta A","ASDF9631",24);
		Person p3 = new Person("Ashwini S","PSYU8521",22);

		Integer i1 = new Integer(20);
		Integer i2 = new Integer(30);
		Integer i3 = new Integer(20);
		
		System.out.println("i1= "+i1);
		System.out.println("i2= "+i2);
		System.out.println("i3= "+i3);
		
		if(i1.equals(i2))
		{
			System.out.println("Same");
		}
		else
		{
			System.out.println("Not Same");
		}
		System.out.println("HashCode of p1= "+p1.hashCode());
		System.out.println("HashCode of p2= "+p2.hashCode());
		System.out.println("HashCode of p3= "+p3.hashCode());
		
		System.out.println("HashCode of i1= "+i1.hashCode());
		System.out.println("HashCode of i2= "+i2.hashCode());
		System.out.println("HashCode of i3= "+i3.hashCode());
	}

}
