
public class TestDrawingApp 
{

	public static void main(String[] args) 
	{
		Shape shape1 = new Circle();
		Shape shape2 = new Circle();
		Shape shape3 = new Sphere();

		System.out.println(" Area of Circle : "+shape1.calcArea());
		System.out.println(" Perimeter: "+shape1.calcPerimeter());
		
		System.out.println("************************************************");
		
		System.out.println(" Area of Circle : "+shape2.calcArea());
		System.out.println(" Perimeter: "+shape2.calcPerimeter());
		
		System.out.println("************************************************");
		
		System.out.println(" Volume: "+shape3.calcArea());
		System.out.println(" Surface Area: "+shape3.calcPerimeter());
		
	}

}
