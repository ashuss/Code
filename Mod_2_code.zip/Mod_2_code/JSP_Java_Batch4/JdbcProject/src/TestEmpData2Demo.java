import java.sql.*;
import java.util.Scanner;

public class TestEmpData2Demo 
{

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Connection con = null;
		PreparedStatement pst;
		int num;
        System.out.println("Enter number of Employees:");
        num = sc.nextInt();
		
		try
		{
			
			Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			String insertQry = "INSERT INTO emp_112081(emp_id,emp_name,emp_sal) VALUES(?,?,?)";
			
			pst = con.prepareStatement(insertQry);
			for(int i=0;i<num;i++)
			{
				System.out.println("Enter Id: ");
				int empId = sc.nextInt();
				System.out.println("Enter Name: ");
				String empName = sc.next();
				System.out.println("Enter Salary: ");
				float empSal = sc.nextFloat();
				
				
				pst.setInt(1,empId);
				pst.setString(2, empName);
				pst.setFloat(3, empSal);
				
				int dataAdded = pst.executeUpdate();
				System.out.println("Data is added ...");
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 

	}

}
