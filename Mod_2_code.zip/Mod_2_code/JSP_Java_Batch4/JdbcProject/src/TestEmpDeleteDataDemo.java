import java.sql.*;
import java.util.Scanner;
public class TestEmpDeleteDataDemo 
{

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Connection con = null;
		PreparedStatement pst;
		Statement st = null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			
			String deleteQry = "DELETE FROM emp_112081 WHERE emp_id = 777";
			
			st = con.createStatement();
			int data = st.executeUpdate(deleteQry);
			System.out.println("Data Deleted from table :"+data);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
	}

}
