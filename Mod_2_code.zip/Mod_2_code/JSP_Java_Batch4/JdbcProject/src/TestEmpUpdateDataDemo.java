import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class TestEmpUpdateDataDemo 
{

	public static void main(String[] args) 
	{
		Connection con = null;
		Statement st = null;

		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			String updateQry = "UPDATE emp_112081 set emp_sal = emp_sal+10000 where emp_sal < 25000";
			st = con.createStatement();
			int data = st.executeUpdate(updateQry);
			System.out.println("Data Updated in table :"+data);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 

	}

}
