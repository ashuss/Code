import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class TestEmpSwitchDemo 
{

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			
			System.out.println("What type of Emp you Want? "+"\n1:DISPLAY\n2:INSERT\n3:DELETE\n4:UPDATE");
			System.out.println("Enter Choice?");
			int choice = sc.nextInt();	//Choice of employees
			
			PreparedStatement pst;
			switch(choice)	//switch case
			{
				case 1: st = con.createStatement();
				String selQry = "SELECT emp_id,emp_name,emp_sal FROM  emp_112081";
				rs = st.executeQuery(selQry);
			
				System.out.println("ID \t NAME \t SALARY");
				while(rs.next())
				{
					System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getInt("emp_sal"));
				}
				
				
				case 2: int num;
		        System.out.println("Enter number of Employees:");
		        num = sc.nextInt(); 
					String insertQry = "INSERT INTO emp_112081(emp_id,emp_name,emp_sal) VALUES(?,?,?)";
				
				pst = con.prepareStatement(insertQry);
				for(int i=0;i<num;i++)
				{
					System.out.println("Enter Id: ");
					int empId = sc.nextInt();
					System.out.println("Enter Name: ");
					String empName = sc.next();
					System.out.println("Enter Salary: ");
					float empSal = sc.nextFloat();
					
					
					pst.setInt(1,empId);
					pst.setString(2, empName);
					pst.setFloat(3, empSal);
					
					int dataAdded = pst.executeUpdate();
					System.out.println("Data is added ...");
				}
				
				case 3: String deleteQry = "DELETE FROM emp_112081 WHERE emp_id = ?";
				
				pst = con.prepareStatement(deleteQry);
				System.out.println("Enter Id: ");
				int empId = sc.nextInt();
				pst.setInt(1,empId);
				int data = pst.executeUpdate();
				System.out.println("Data is deleted...");
				
				case 4:
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
