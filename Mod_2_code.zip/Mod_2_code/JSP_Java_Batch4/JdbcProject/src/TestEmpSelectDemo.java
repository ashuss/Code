import java.sql.*;


public class TestEmpSelectDemo 
{

	public static void main(String[] args) 
	{
		//Load oracle tYpe 4 driver in memory
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");//check exception
			st = con.createStatement();
			String selQry = "SELECT emp_id,emp_name,emp_sal FROM  emp_112081";
			rs = st.executeQuery(selQry);
		
			System.out.println("ID \t NAME \t SALARY");
			while(rs.next())
			{
				System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getInt("emp_sal"));
			}
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		
	}

}
