import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;


public class TestResuSetMetaData 
{

	public static void main(String[] args) 
	{
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM emp_112081");
			rsmd = rs.getMetaData();
			
			int columnCount = rsmd.getColumnCount();
			
			System.out.println("No of Columns : "+columnCount);
			
			for(int i=0;i<columnCount;i++)
			{
				System.out.println(i+" Column Name: "+rsmd.getColumnName(i));
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
