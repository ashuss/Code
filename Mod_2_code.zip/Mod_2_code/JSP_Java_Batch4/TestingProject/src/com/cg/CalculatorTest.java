package com.cg;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
public class CalculatorTest 
{
	Calculator cc = new Calculator();;
	@BeforeClass
	public static void calcBeforeClass()
	{
		
		System.out.println("This is invoked by jUnit runner once before the execution of all the test cases");
		
	}
	
	@AfterClass
	public static void calcAfterClass()
	{
		System.out.println("This is invoked by jUnit runner once after the execution of all the test cases");
		
	}
	
	@Before
	public void calcBefore()
	{
		System.out.println("This is invoked by jUnit runner once before the execution of each test cases");
		
	}
	
	@After
	public void calcAfter()
	{
		System.out.println("This is invoked by jUnit runner once after the execution of each test cases");
	}
	
	@Test
	public void testDivide1()
	{
		Assert.assertEquals(2,cc.divide(50));
		
	}
	@Test
	public void testDivide2()
	{
		Assert.assertEquals(1,cc.divide(100));
		
	}
	@Test
	public void testDivide3()
	{
		Assert.assertEquals(-100,cc.divide(-1));
		
	}
	@Test(expected=ArithmeticException.class)
	public void testDivide4()
	{
		Assert.assertEquals(1,cc.divide(0));
		
	}

}
