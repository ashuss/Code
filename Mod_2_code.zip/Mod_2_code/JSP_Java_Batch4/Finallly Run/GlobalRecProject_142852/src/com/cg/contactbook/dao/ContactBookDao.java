package com.cg.contactbook.dao;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;

public interface ContactBookDao 
{
	public int generateEnqryId()throws ContactBookException;
	public int addEnquiry(EnquiryBean enqry)throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException;	
}
