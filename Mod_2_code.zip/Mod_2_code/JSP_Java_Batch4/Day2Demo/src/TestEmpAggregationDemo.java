import java.util.Scanner;
public class TestEmpAggregationDemo {

	public static void main(String[] args) 
	{
		//Date ashuDOJ = new Date(13,12,2017);
		//Date rahulDOJ = new Date(31,12,2017);
		
		//Employee ashwini = new Employee(1423021,"Ashwini S",1000.0F,ashuDOJ);
		//Employee rahul = new Employee(1423022,"Rahul D",2000.0F,rahulDOJ);

		//System.out.println(ashwini.dispEmpInfo());
		//System.out.println(rahul.dispEmpInfo());
		
		Scanner sc= new Scanner(System.in);
		
		Date empDOJ;
		int d=0, m=0, y=0;
		Employee allEmp[] = new Employee[3];
		int empId=0;
		String empName="Unknown";
		float empSal=0.0F;
		
		
		for(int i=0;i<allEmp.length;i++)
		{
			System.out.println("Enter ID :");
			empId = sc.nextInt();
			
			System.out.println("Enter Name :");
			empName= sc.next();
			
			System.out.println("Enter Salary :");
			empSal = sc.nextFloat();
			
			System.out.println("Enter Date = ");
			System.out.println("Enter day = ");
			d = sc.nextInt();
			
			System.out.println("Enter month = ");
			m = sc.nextInt();
			
			System.out.println("Enter year = ");
			y = sc.nextInt();
			
			empDOJ = new Date(d,m,y);
			allEmp[i] = new Employee(empId, empName, empSal, empDOJ);
		}
		
		for(int j=0;j<allEmp.length;j++)
		{
			System.out.println(" Employee Details : "+allEmp[j].dispEmpInfo());
		}
		

	}

}
