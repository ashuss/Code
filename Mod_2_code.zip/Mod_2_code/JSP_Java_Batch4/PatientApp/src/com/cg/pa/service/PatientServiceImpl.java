package com.cg.pa.service;

import java.util.ArrayList;
import java.util.regex.Pattern;



import com.cg.pa.bean.Patient;
import com.cg.pa.dao.PatientDao;
import com.cg.pa.dao.PatientDaoImpl;
import com.cg.pa.exception.PatientException;

public class PatientServiceImpl 
implements PatientService
{
	PatientDao pDao = null;
	
	public  PatientServiceImpl()
	{
		pDao = new PatientDaoImpl();
	}

	@Override
	public int addPatientDetails(Patient patient) throws PatientException
	{
		return pDao.addPatientDetails(patient);
	}

	@Override
	public int generatePatientId() throws PatientException 
	{
		return pDao.generatePatientId();
	}

	@Override
	public Patient getAppliantDetails(int patientId) throws PatientException 
	{
		return pDao.getAppliantDetails(patientId);
	}

	@Override
	public boolean isValidPatient(int pid) throws PatientException
	{
		ArrayList<Integer> pId = pDao.validatePatientId();
		for(Integer p:pId)
		{
			if(pid == p)
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean validateName(String name) throws PatientException 
	{
		String namePattern="[A-Z][a-z]{1,20}";
        if(Pattern.matches(namePattern, name))
        {
            return true;
        }
        else
        {
            throw new PatientException("Only characters allowed and starts with Capital e.g. Asmita");
        }  
	}

	@Override
	public boolean validateAge(int page) throws PatientException 
	{
		String namePattern="[0-9]{2}";
        if(Pattern.matches(namePattern, new Integer(page).toString()))
        {
            return true;
        }
        else
        {
            throw new PatientException("Invalid Age");
        } 
	}

	@Override
	public boolean validateContactNo(long contactNo) throws PatientException 
	{
		String numPattern = "[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, new Long(contactNo).toString()))
		{
			return true;
		}
		else
		{
			throw new PatientException("Invalid Phone No");
		}
	}

	@Override
	public ArrayList<Integer> validatePatientId() throws PatientException 
	{
		return pDao.validatePatientId();
	}

}
