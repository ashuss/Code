package com.cg.pa.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import java.util.ArrayList;

import com.cg.pa.bean.Patient;
import com.cg.pa.exception.PatientException;
import com.cg.pa.util.DBUtil;

public class PatientDaoImpl 
implements PatientDao
{
	
	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;

	@Override
	public int addPatientDetails(Patient patient) throws PatientException 
	{
		String insertQry = "INSERT INTO Patient VALUES(?,?,?,?,?,sysdate)";
   	 	int addedData =0;
   
   	 	try 
   	 	{
			con = DBUtil.getCon();
			
			pst = con.prepareStatement(insertQry);
			
			pst.setInt(1, generatePatientId());
			pst.setString(2, patient.getName());
			pst.setInt(3, patient.getAge());
			pst.setLong(4, patient.getPhoneNo());
			pst.setString(5, patient.getDescription());
			
			addedData = pst.executeUpdate();		
   	 	}
   	 	catch (Exception e) 
   	 	{
   	 		throw new 
   	 		PatientException(e.getMessage());
		} 
   	 	finally
   	 	{
   		
   	 		try 
   	 		{
   				pst.close();
				con.close();
			} 
   	 		catch (SQLException e) 
   	 		{
   	 			
				throw new PatientException(e.getMessage());
				
			}
   	 	}
   	 	
		return addedData;
	}
	
	
	@Override
	public int generatePatientId() throws PatientException 
	{
		String qry = "SELECT pat_id_seq.NEXTVAL FROM DUAL";
    	int valueGenerated;
        try 
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(qry);
            rs.next();
            valueGenerated = rs.getInt(1);
        } 
        catch (Exception e) 
        {
            throw new 
            PatientException(e.getMessage());
        }
        finally
        {
            try
            {
            	rs.close();
            	st.close();
            	con.close();
            }
            catch(SQLException e)
            {
            	throw new
            	PatientException(e.getMessage());
            }
        }
        return valueGenerated;
	}

	@Override
	public Patient getAppliantDetails(int patientId) throws PatientException 
	{
		String selectQry = "SELECT * FROM Patient WHERE patientId = ?";
		
		Patient patient = null;
		try 
   	 	{
			con = DBUtil.getCon();
			pst = con.prepareStatement(selectQry);
			pst.setLong(1,patientId);
			rs = pst.executeQuery();
			
			if(rs.next())
			{
				
				patient = new Patient(rs.getInt("patientId"),
						rs.getString("name"),
						rs.getInt("age"),
						rs.getLong("phoneNo"),
						rs.getString("description"),
						rs.getDate("consult_date").toLocalDate());
				
			}
			
		} 
   	 	catch (Exception e) 
   	 	{
   	 		throw new 
   	 		PatientException(e.getMessage());
		} 
   	 	finally
   	 	{
   		
   	 		try 
   	 		{
   	 			rs.close();
   				pst.close();
				con.close();
			} 
   	 		catch (SQLException e) 
   	 		{
				throw new PatientException(e.getMessage());
				
			}
   	 	}
   	 	
		
		return patient;
	}


	@Override
	public ArrayList<Integer> validatePatientId() throws PatientException 
	{
		ArrayList<Integer> pList = new ArrayList<Integer>();
		String qry = "SELECT patientId from Patient";
		try
		{
			con = DBUtil.getCon();
			st = con.createStatement();
			rs = st.executeQuery(qry);
			while(rs.next())
			{
				int p = rs.getInt("patientId");
				pList.add(p);
			}
		}
		catch (Exception e) 
	 		{
			throw new PatientException(e.getMessage());
			
		}
		finally
        {
            try
            {
            	rs.close();
            	st.close();
            	con.close();
            }
            catch(SQLException e)
            {
            	throw new
            	PatientException(e.getMessage());
            }
        }
		return pList;
		
	}

}
