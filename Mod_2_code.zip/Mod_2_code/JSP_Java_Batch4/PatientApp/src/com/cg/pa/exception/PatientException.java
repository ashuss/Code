package com.cg.pa.exception;

public class PatientException extends Exception
{
	public PatientException(String msg)
	{
		super(msg);					//Error Message
	}
}
