package com.cg.pa.service;

import java.util.ArrayList;

import com.cg.pa.bean.Patient;
import com.cg.pa.exception.PatientException;

public interface PatientService 
{
	public int addPatientDetails(Patient patient)
	throws PatientException;
			
	public int generatePatientId() 
	throws PatientException;
			
	public ArrayList<Integer> validatePatientId()
			throws PatientException;
	
	public Patient getAppliantDetails(int patientId)
	throws PatientException;
	
	public boolean isValidPatient(int pid)
	throws PatientException;
			
	public boolean validateName(String name)
	throws PatientException;

	public boolean validateAge(int page)
	throws PatientException;

	public boolean validateContactNo(long contactNo)
	throws PatientException;
}
