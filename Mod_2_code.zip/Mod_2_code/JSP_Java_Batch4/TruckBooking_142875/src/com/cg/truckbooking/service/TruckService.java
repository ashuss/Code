package com.cg.truckbooking.service;

import java.util.ArrayList;


import com.cg.truckbooking.bean.BookingDetails;
import com.cg.truckbooking.bean.TruckDetails;
import com.cg.truckbooking.exception.TruckException;

public interface TruckService 
{
	public ArrayList<TruckDetails> getAllTruck()
			throws TruckException;

	public int addBookingDetails(BookingDetails book)
			throws TruckException;

	public int generateBookingId()
			throws TruckException;
			
	public TruckDetails getTruckDetails(int truckId)
			throws TruckException;
			
	public ArrayList<Integer> validateTruckId()
			throws TruckException;
	
	public boolean validateGenerateTruckQuantity(int qty)
			throws TruckException;
	
	public boolean isValidTruck(int tid)
			throws TruckException;

	public boolean validateCustId(String cid)
			throws TruckException;
	
	public boolean validateContactNo(long contactNo)
			throws TruckException;
	
	public boolean validateDate(String date)
			throws TruckException;
}
