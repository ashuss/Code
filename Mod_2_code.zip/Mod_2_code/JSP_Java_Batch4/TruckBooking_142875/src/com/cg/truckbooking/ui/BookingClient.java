package com.cg.truckbooking.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;








import com.cg.truckbooking.bean.BookingDetails;
import com.cg.truckbooking.bean.TruckDetails;
import com.cg.truckbooking.exception.TruckException;
import com.cg.truckbooking.service.TruckService;
import com.cg.truckbooking.service.TruckServiceImpl;

public class BookingClient 
{

	static Scanner sc = null;
	static TruckService tSer = null;

	public static void main(String[] args) throws TruckException 
	{
		tSer = new TruckServiceImpl();
		sc = new Scanner(System.in);
		int choice = 0 ; 
		
		while(true)
		{
			System.out.println("Select an Operation: ");
			System.out.println("1. Book Trucks\n2. Exit");
			System.out.println("****************************");
			System.out.println("Please enter a Choice : ");
			choice = sc.nextInt();
			
			switch(choice)
			{
			case 1:
				insertDetails();
				break;
			default :
				System.exit(0);
			}
		}
	}

	private static void insertDetails() throws TruckException 
	{
		fetchAllData();
		BookingDetails bd = new BookingDetails();
		System.out.println("Please Enter Cutomer Id  : ");
		String custid = sc.next();
		try
		{
			if(tSer.validateCustId(custid))
			System.out.println("Please Enter Truck Id : ");
			int tid = sc.nextInt();	
			if(tSer.isValidTruck(tid))
			{
				System.out.println("Enter number of Trucks : ");
				int q = sc.nextInt();
				if(tSer.validateGenerateTruckQuantity(q))
				{
					System.out.println("Enter Customer Mobile :");
					long mob = sc.nextLong();
					if(tSer.validateContactNo(mob))
					{
						System.out.println("Enter date Of Transportation :  in yyyy-MM-dd format");
						String d = sc.next();
						//LocalDate d1 = LocalDate.parse(d);
						bd.setCustId(custid);
						bd.setTruckId(tid);
						bd.setNoOfTrucks(q);
						bd.setCustMobile(mob);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						bd.setDateOfTransport(LocalDate.parse(d, format));
						
						
						int dataAdded = tSer.addBookingDetails(bd);
						
						if(dataAdded == 1)
						{
							System.out.println("Thank You. Your Booking Id is :  "+tSer.generateBookingId());
						}
						else
						{
							System.out.println("May be Some Exception while addition");
						}
					}
				}
			}
		}catch (TruckException e)
	    {
	        
	        System.out.println(e.getMessage());
	    }
		}

	private static void fetchAllData() 
	{
		
		try
		 {
		   ArrayList<TruckDetails> tList = tSer.getAllTruck();
	       for(TruckDetails truck:tList)
		     {
		       System.out.println(truck);
					
		     }
		  }
	         catch(TruckException e)
		        {
		         System.out.println(e.getMessage());
		        }
	}

}
