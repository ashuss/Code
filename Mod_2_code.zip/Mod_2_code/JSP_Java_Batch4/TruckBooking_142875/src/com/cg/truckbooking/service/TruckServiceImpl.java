package com.cg.truckbooking.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;




import com.cg.truckbooking.bean.BookingDetails;
import com.cg.truckbooking.bean.TruckDetails;
import com.cg.truckbooking.dao.TruckDao;
import com.cg.truckbooking.dao.TruckDaoImpl;
import com.cg.truckbooking.exception.TruckException;

public class TruckServiceImpl 
implements TruckService
{

	TruckDao tDao = null;
	
	public TruckServiceImpl()
	{
		tDao = new TruckDaoImpl();
	}
	
	
	@Override
	public ArrayList<TruckDetails> getAllTruck() throws TruckException 
	{
		return tDao.getAllTruck();
	}

	/*****************************************************/
	
	@Override
	public int addBookingDetails(BookingDetails book) throws TruckException 
	{
		return tDao.addBookingDetails(book);
	}

	/*******************************************************/
	
	@Override
	public int generateBookingId() throws TruckException 
	{
		return tDao.generateBookingId();
	}

	/*******************************************************/
	
	@Override
	public TruckDetails getTruckDetails(int truckId) throws TruckException 
	{
		return tDao.getTruckDetails(truckId);
	}
	
	/******************************************************/
	
	@Override
	public ArrayList<Integer> validateTruckId() throws TruckException 
	{
		return tDao.validateTruckId();
	}

	/************************************************************/
	
	@Override
	public boolean isValidTruck(int tid) throws TruckException 
	{
		ArrayList<Integer> tId = tDao.validateTruckId();
		for(Integer t:tId)
		{
			if(tid == t)
			{
				return true;
			}
		}
		return false;
	}
	/*****************************************************/
	

	@Override
	public boolean validateCustId(String cid) throws TruckException 
	{
		String namePattern="[A-Z][0-9]{6}";
        if(Pattern.matches(namePattern,cid ))
        {
            return true;
        }
        else
        {
            throw new TruckException("Invalid Customer id");
        }  
	}


	@Override
	public boolean validateGenerateTruckQuantity(int qty)
			throws TruckException 
	{
        if(qty>0)
        {
            return true;
        }
        else
        {
        	throw new TruckException("Invalid Customer id");
        }
	}


	@Override
	public boolean validateContactNo(long contactNo) throws TruckException 
	{
		String numPattern = "[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, new Long(contactNo).toString()))
		{
			return true;
		}
		else
		{
			throw new TruckException("Invalid Phone No");
		}
	}


	@Override
	public boolean validateDate(String date) throws TruckException 
	{
		if(date.compareTo(LocalDate.now().toString()) > 0)
		{
			return true;
		}
		return false;
	}

}
