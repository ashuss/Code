package com.cg.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.truckbooking.bean.BookingDetails;
import com.cg.truckbooking.bean.TruckDetails;
import com.cg.truckbooking.exception.TruckException;
import com.cg.truckbooking.util.DBUtil;

public class TruckDaoImpl 
implements TruckDao
{

	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    
    Scanner sc=new Scanner(System.in);
    Logger truckLog = null;
    
    public TruckDaoImpl()
    {
    	PropertyConfigurator.configure("truck/log4j.properties"); 
    	truckLog=Logger.getLogger("TruckDaoImpl.class");
    }
    
	@Override
	public ArrayList<TruckDetails> getAllTruck() throws TruckException
	{
		ArrayList<TruckDetails> truckList = new ArrayList<TruckDetails>();

		String selectQry="SELECT * FROM TruckDetails";

		TruckDetails truck = null;

		try{
				con=DBUtil.getCon();
				st=con.createStatement();
				rs=st.executeQuery(selectQry);
				
				while(rs.next())
				{
					truck = new TruckDetails(rs.getInt("truckId"),rs.getString("truckType"),
							rs.getString("origin"),rs.getString("destination"),
							rs.getDouble("charges"),rs.getInt("availableNos"));
					truckList.add(truck);	
					
				}
				
			}
			catch(Exception e)
			{
				throw new TruckException(e.getMessage());
			}
			
			finally
			{
				try {
					rs.close();
					st.close();
					con.close();
				} catch (SQLException e) 
				{
					throw new TruckException(e.getMessage());
			}
			}
			
			
			return truckList;
		}
	

	
	/*********************************************************************************/
	
	@Override
	public int addBookingDetails(BookingDetails book) throws TruckException 
	{
		String insertQry=" INSERT INTO BookingDetails VALUES(?,?,?,?,?,?)";

		int dataAdded=0;

		try{
		
		con=DBUtil.getCon();
		pst=con.prepareStatement(insertQry);
		
		pst.setInt(1, generateBookingId());
		pst.setString(2, book.getCustId());
		pst.setLong(3, book.getCustMobile());
		pst.setInt(4, book.getTruckId());
		pst.setInt(5, book.getNoOfTrucks());
		pst.setDate(6, Date.valueOf(book.getDateOfTransport()));
		
		dataAdded = pst.executeUpdate();

		truckLog.info("Booking details inserted "+book);
		
		}
	
		catch(Exception e)
		{
			
			throw new TruckException(e.getMessage());
		}
		
		return dataAdded;
	}
	
	



	/************************************************************************************/
	

	@Override
	public int generateBookingId() throws TruckException 
	{
		String qry = "SELECT booking_id_seq.NEXTVAL FROM DUAL";
    	int valueGenerated;
        try 
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(qry);
            rs.next();
            valueGenerated = rs.getInt(1);
        } 
        catch (Exception e) 
        {
            throw new 
            TruckException(e.getMessage());
        }
        finally
        {
            try
            {
            	rs.close();
            	st.close();
            	con.close();
            }
            catch(SQLException e)
            {
            	throw new
            	TruckException(e.getMessage());
            }
        }
        return valueGenerated;
	}

	/*************************************************************************************/
	
	@Override
	public TruckDetails getTruckDetails(int truckId) throws TruckException 
	{
String selectQry = "SELECT * FROM TruckDetails WHERE truckId = ?";
		
		TruckDetails truck = null;
		try 
   	 	{
			con = DBUtil.getCon();
			pst = con.prepareStatement(selectQry);
			pst.setInt(1,truckId);
			rs = pst.executeQuery();
			
			if(rs.next())
			{
				
				truck = new TruckDetails(rs.getInt("truckId"),rs.getString("truckType"),
						rs.getString("origin"),rs.getString("destination"),
						rs.getDouble("charges"),rs.getInt("availableNos"));
				
			}
			
		} 
   	 	catch (Exception e) 
   	 	{
   	 		throw new 
   	 		TruckException(e.getMessage());
		} 
   	 	finally
   	 	{
   		
   	 		try 
   	 		{
   	 			rs.close();
   				pst.close();
				con.close();
			} 
   	 		catch (SQLException e) 
   	 		{
				throw new TruckException(e.getMessage());
				
			}
   	 	}
   	 	
		
		return truck;
	}

	/***************************************************************************/

	@Override
	public ArrayList<Integer> validateTruckId() throws TruckException 
	{
		ArrayList<Integer> tList = new ArrayList<Integer>();
		String qry = "SELECT truckId from TruckDetails";
		try
		{
			con = DBUtil.getCon();
			st = con.createStatement();
			rs = st.executeQuery(qry);
			while(rs.next())
			{
				int t = rs.getInt("truckId");
				tList.add(t);
			}
		}
		catch (Exception e) 
	 		{
			throw new TruckException(e.getMessage());
			
		}
		finally
        {
            try
            {
            	rs.close();
            	st.close();
            	con.close();
            }
            catch(SQLException e)
            {
            	throw new TruckException(e.getMessage());
            }
        }
		return tList;
	}

/***********************************************************************************/

	@Override
	public int generateTruckQuantity(BookingDetails bd) throws TruckException 
	{
		String selectqry="SELECT availableNos FROM TruckDetails WHERE truckId=?";
		int qty=0;
		try{
		con=DBUtil.getCon();
		pst=con.prepareStatement(selectqry);
		pst.setInt(1,bd.getTruckId());
		rs=pst.executeQuery();
		rs.next();
		qty=rs.getInt(1);
		}
		catch(Exception e)
		{
			throw new TruckException(e.getMessage());
		}
		finally
		{
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) 
			{
				
				throw new TruckException(e.getMessage());
		}
		}
		return qty;
	}

}
