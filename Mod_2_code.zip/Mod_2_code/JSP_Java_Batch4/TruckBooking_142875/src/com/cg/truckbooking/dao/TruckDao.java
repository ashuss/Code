package com.cg.truckbooking.dao;

import java.util.ArrayList;

import com.cg.truckbooking.bean.BookingDetails;
import com.cg.truckbooking.bean.TruckDetails;
import com.cg.truckbooking.exception.TruckException;

public interface TruckDao 
{

	public ArrayList<TruckDetails> getAllTruck()
	throws TruckException;

	public int addBookingDetails(BookingDetails book)
	throws TruckException;

	public int generateBookingId()
	throws TruckException;
	
	public TruckDetails getTruckDetails(int truckId)
	throws TruckException;
	
	public ArrayList<Integer> validateTruckId()
	throws TruckException;
	
	public int generateTruckQuantity(BookingDetails bd)
	throws TruckException; 
}
