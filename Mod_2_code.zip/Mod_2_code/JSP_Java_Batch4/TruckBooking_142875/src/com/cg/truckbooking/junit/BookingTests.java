package com.cg.truckbooking.junit;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.truckbooking.bean.BookingDetails;
import com.cg.truckbooking.dao.TruckDao;
import com.cg.truckbooking.dao.TruckDaoImpl;
import com.cg.truckbooking.exception.TruckException;

public class BookingTests
{
	 static TruckDao tDao = null;
	 static BookingDetails b = null;
	    @BeforeClass
	    public static void beforeClass() throws TruckException
	    {
	    	tDao = new TruckDaoImpl();
	        b = new BookingDetails(tDao.generateBookingId(),"A111222",8796541203L,1004,2,LocalDate.now());
	    }
	    @Test
	    public void testAddData1() throws TruckException
	    {
	        Assert.assertNotNull(tDao.addBookingDetails(b));
	    }
	    @Test(expected=TruckException.class)
	    public void testAddEnq2() throws Exception
	    {
	        Assert.assertEquals(1,tDao.addBookingDetails(b));
	    }
	   
}
