package com.cg.truckbooking.exception;

public class TruckException extends Exception
{
	public TruckException(String msg)
	{
		super(msg);
	}
}
