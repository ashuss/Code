
public class NoDataAvailableException extends RuntimeException{
    NoDataAvailableException (String msg)
    {
        super(msg);
    } 
}
