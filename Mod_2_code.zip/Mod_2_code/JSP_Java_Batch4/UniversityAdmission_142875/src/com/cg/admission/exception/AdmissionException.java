package com.cg.admission.exception;

public class AdmissionException extends Exception
{
	public AdmissionException(String msg)
	{
		super(msg);					//Error Message
	}

}
