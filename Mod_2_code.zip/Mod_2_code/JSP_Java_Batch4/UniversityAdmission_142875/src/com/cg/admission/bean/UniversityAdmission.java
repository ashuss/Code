package com.cg.admission.bean;

public class UniversityAdmission 
{
	//Variable Declaration
	
	private long applyId;
	private String fName;
	private String lName;
	private String email;
	//private String contactNo;
	private long contactNo;
	private String stream;
	private Float aggregate;
	
	
	//Constructor With Field
	
	public UniversityAdmission(long applyId, String fName, String lName,
			String email, long contactNo, String stream, float aggregate) 		
	{
		super();
		this.applyId = applyId;
		this.fName = fName;
		this.lName = lName;
		this.email = email;
		this.contactNo = contactNo;
		this.stream = stream;
		this.aggregate = aggregate;
	}


	//Getter Setter Operation
	
	public long getApplyId() 
	{
		return applyId;
	}


	public void setApplyId(long applyId) 
	{
		this.applyId = applyId;
	}


	public String getfName() 
	{
		return fName;
	}


	public void setfName(String fName) 
	{
		this.fName = fName;
	}


	public String getlName() 
	{
		return lName;
	}


	public void setlName(String lName) 
	{
		this.lName = lName;
	}


	public String getEmail() 
	{
		return email;
	}


	public void setEmail(String email) 
	{
		this.email = email;
	}


	public long getContactNo() 
	{
		return contactNo;
	}


	public void setContactNo(long contactNo) 
	{
		this.contactNo = contactNo;
	}


	public String getStream() 
	{
		return stream;
	}


	public void setStream(String stream) 
	{
		this.stream = stream;
	}


	public float getAggregate() 
	{
		return aggregate;
	}


	public void setAggregate(float aggregate) 
	{
		this.aggregate = aggregate;
	}

	
	//toString() 

	@Override
	public String toString() 
	{
		return "UniversityAdmission \napplyId=" + applyId + "\n fName=" + fName
				+ "\n lName=" + lName + "\n email=" + email + "\n contactNo="
				+ contactNo + "\n stream=" + stream + "\n aggregate=" + aggregate;
	}

	
	//empty Constructor

	public UniversityAdmission() 
	{
		super();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
