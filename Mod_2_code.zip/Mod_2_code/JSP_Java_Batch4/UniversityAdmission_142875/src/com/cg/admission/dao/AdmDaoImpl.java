package com.cg.admission.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.admission.bean.UniversityAdmission;
import com.cg.admission.exception.AdmissionException;
import com.cg.admission.util.DBUtil;






public class AdmDaoImpl
implements AdmDao
{

	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    Logger admLogger = null;
    
   
    public AdmDaoImpl() 
    {
    	PropertyConfigurator.configure("admission/log4j.properties"); 
	    admLogger=Logger.getLogger("AdmDaoImpl.class");
	}



	public int addAppliantDetails(UniversityAdmission applicant)
    throws AdmissionException 
    {
    	String insertQry = "INSERT INTO Candidate_Detail(applyId,firstname,lastname,contactNo,email,aggregate,stream) VALUES(?,?,?,?,?,?,?)";
   	 	int addedData =0;
   
   	 	try 
   	 	{
			con = DBUtil.getCon();
			pst = con.prepareStatement(insertQry);
			
			pst.setLong(1, generateApplicantId());
			pst.setString(2, applicant.getfName());
			pst.setString(3, applicant.getlName());
			pst.setString(5, applicant.getEmail());
			pst.setLong(4, applicant.getContactNo());
			pst.setFloat(6, applicant.getAggregate());
			pst.setString(7, applicant.getStream());
			
			addedData = pst.executeUpdate();	
			
			admLogger.log(Level.INFO, "Emp Inserted: "+applicant);
			
		} 
   	 	catch (Exception e) 
   	 	{
   	 		throw new 
   	 		AdmissionException(e.getMessage());
		} 
   	 	finally
   	 	{
   		
   	 		try 
   	 		{
   				pst.close();
				con.close();
			} 
   	 		catch (SQLException e) 
   	 		{
   	 			admLogger.error("This is Exception: "+e.getMessage());
				throw new AdmissionException(e.getMessage());
				
			}
   	 	}
   	 	
		return addedData;
	}



    public long generateApplicantId() 
    throws AdmissionException
	{
		String qry = "SELECT apply_id_seq.NEXTVAL FROM DUAL";
    	int valueGenerated;
        try 
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(qry);
            rs.next();
            valueGenerated = rs.getInt(1);
        } 
        catch (Exception e) 
        {
            throw new 
            AdmissionException(e.getMessage());
        }
        finally
        {
            try
            {
            	rs.close();
            	st.close();
            	con.close();
            }
            catch(SQLException e)
            {
            	throw new
            	AdmissionException(e.getMessage());
            }
        }
        return valueGenerated;
	}
    

	public UniversityAdmission getAppliantDetails(long applicantId)
	throws AdmissionException
	{
		String selectQry = "SELECT * FROM Candidate_Detail WHERE applyId = ?";
		
		UniversityAdmission ua = null;
		try 
   	 	{
			con = DBUtil.getCon();
			pst = con.prepareStatement(selectQry);
			pst.setLong(1,applicantId);
			rs = pst.executeQuery();
			
			if(rs.next())
			{
				
				ua = new UniversityAdmission(rs.getLong("applyId"),
						rs.getString("firstname"),
						rs.getString("lastName"),
						rs.getString("email"),
						rs.getLong("contactNo"),
						rs.getString("stream"),
						rs.getFloat("aggregate"));
				
			}
			
		} 
   	 	catch (Exception e) 
   	 	{
   	 		throw new 
   	 		AdmissionException(e.getMessage());
		} 
   	 	finally
   	 	{
   		
   	 		try 
   	 		{
   	 			rs.close();
   				pst.close();
				con.close();
			} 
   	 		catch (SQLException e) 
   	 		{
				throw new AdmissionException(e.getMessage());
				
			}
   	 	}
   	 	
		
		return ua;
		
	}



	@Override
	public long generateApplicantId(long aaplicantId) throws AdmissionException {
		// TODO Auto-generated method stub
		return 0;
	}
    	
}

