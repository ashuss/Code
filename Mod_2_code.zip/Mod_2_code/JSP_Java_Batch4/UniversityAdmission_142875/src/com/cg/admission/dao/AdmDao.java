package com.cg.admission.dao;

import com.cg.admission.bean.UniversityAdmission;
import com.cg.admission.exception.AdmissionException;


public interface AdmDao 
{
	
	public int addAppliantDetails(UniversityAdmission applicant)
	throws AdmissionException;
	
	public long generateApplicantId(long aaplicantId) 
	throws AdmissionException;
	
	
	public UniversityAdmission getAppliantDetails(long applicantId)
	throws AdmissionException;    

	
	

}
