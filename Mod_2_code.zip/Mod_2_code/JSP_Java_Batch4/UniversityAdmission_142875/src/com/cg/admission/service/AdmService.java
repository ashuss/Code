package com.cg.admission.service;

import com.cg.admission.bean.UniversityAdmission;
import com.cg.admission.exception.AdmissionException;


public interface AdmService 
{

	public int addAppliantDetails(UniversityAdmission applicant)
	throws AdmissionException;
			
	public long generateApplicantId(long aaplicantId) 
	throws AdmissionException;	
	
	public UniversityAdmission getAppliantDetails(long applicantId)
	throws AdmissionException;
	
	//Validation
	
	public boolean isValidapplicant(long aid)
	throws AdmissionException;
	
	public boolean validateContactNo(long contactNo)
	throws AdmissionException;
	
	public boolean validateFirstname(String fName)
	throws AdmissionException;
			
	public boolean validateLastname(String lName)
	throws AdmissionException;
	
	public boolean validateEmail(String pLocation)
	throws AdmissionException;
	
	public boolean validateAggregate(float aggregate)
	throws AdmissionException;

	public boolean validateStream(String stream)
	throws AdmissionException;

	
	
	
}
