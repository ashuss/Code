//Lab 2- 2.1
public class PersonDetails {

	public static void main(String[] args) 
	{
		String firstName="Divya";
		String lastName="Bharathi";
		char gender='F';
		int age=20;
		float weight=85.55F;
		
		System.out.println("Person Details: ");
		System.out.println("-----------------------");
		System.out.println("First Name: "+firstName);
		System.out.println("Last Name: "+lastName);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
	
	}

}
