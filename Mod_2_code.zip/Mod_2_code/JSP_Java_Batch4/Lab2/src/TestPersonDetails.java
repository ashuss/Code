public class TestPersonDetails {

	public static void main(String[] args) 
	{
		//Lab 2-2.3
		Person p1 = new Person();
		
		p1.setFirstName("Divya");			//set values for parameters
		p1.setLastName("Bharathi");
		p1.setGender('F');
		
		
		System.out.println("Person Details:");
		System.out.println("----------------------------");
		System.out.println("First Name: "+p1.getFirstName());				//get values and display
		System.out.println("Last Name: "+p1.getLastName());
		System.out.println("Gender: "+p1.getGender());

		
		
		
	}

}
