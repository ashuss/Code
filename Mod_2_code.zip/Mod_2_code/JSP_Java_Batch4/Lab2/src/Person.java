
public class Person 
{
	 private String firstName;
	 private String lastName;
	 private  char gender;
	 private Long phoneNo;
	 
	 // 2.3 Getter Setter
	 //get function
	 
	 public String getFirstName()
	 {
		 return firstName;
	 }
	 public String getLastName()
	 {
		 return lastName;
	 }
	 public char getGender()
	 {
		 return gender;
	 }
	
	 //set function
	 
	 public void setFirstName(String firstName)	 //set function
		{
			this.firstName=firstName;
		}
		
		public void setLastName(String lastName)
		{
			this.lastName=lastName;
		}
		
		public void setGender(char gender)
		{
			this.gender=gender;
		}
	 
		//2.4 Constructor 
		public Person()
		 {
		 	firstName = "null";
		 	lastName = "null";
		 	gender = ' ';
		 	phoneNo=0L;
		 }
		 
		 
		 public Person(String firstName, String lastName, char gender, Long phoneNo)
		 {
		 	this.firstName=firstName;
		 	this.lastName=lastName;
		 	this.gender=gender;
		 	this.phoneNo=phoneNo;
		 }
	 public String dispPerson()
	 {
	 	System.out.println("Person Details");
	 	
	 	return 	"First Name = "+firstName+"\n Last Name= " +lastName
	 			+"\n Gender= "+gender+"\n Phone No= "+phoneNo;
	 }
}
