import java.util.Scanner;

public class enumGenderAccept 
{

	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		
		String firstName, lastName;
		Long phoneNo;
		Gender gender;
		
		
		System.out.println("Enter First Name: ");
        firstName = sc.next();
        System.out.println("Enter Last Name: ");
        lastName = sc.next();
        System.out.println("Enter Phone Number: ");
        phoneNo = sc.nextLong();
		System.out.println("Enter Gender : ");
		if(Gender.M == g)
		{
			gender = Gender.M;
			
		}
		
		System.out.println("Enter Gender : ");
		
		Person2_5 p2 = new Person2_5(firstName,lastName,phoneNo,gender);
        
        System.out.println("Person Details:\n________________\n"+p2.dispPerson2_5());

	}

}
