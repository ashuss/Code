enum Gender
{
	M,F;
}


public class Person2_5 
{
	private String firstName;
	 private String lastName;
	 private Long phoneNo;
	 Gender gender;
	 
	 
	 public Person2_5(String firstName, String lastName, Long phoneNo, Gender gender) 
	 {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
		this.gender = gender;
	}


	public String dispPerson2_5() {
		
		System.out.println("Person Details");
		return "First Name = "+firstName+"\n Last Name= " +lastName
	 			+"\n Gender= "+gender+"\n Phone No= "+phoneNo;
	}


	
}
