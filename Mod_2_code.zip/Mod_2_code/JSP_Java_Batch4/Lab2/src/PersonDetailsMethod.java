import java.util.Scanner;

public class PersonDetailsMethod {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		
		String firstName, lastName;
		char gender;
		Long phoneNo;
		
		
		System.out.println("Enter First Name: ");
        firstName = sc.next();
        System.out.println("Enter Last Name: ");
        lastName = sc.next();
        System.out.println("Enter Gender: ");
        gender = sc.next().charAt(0);
        System.out.println("Enter Phone Number: ");
        phoneNo = sc.nextLong();
        
        Person p2 = new Person(firstName,lastName,gender,phoneNo);
        
        System.out.println("Person Details:\n________________\n"+p2.dispPerson());
		

	}

}
