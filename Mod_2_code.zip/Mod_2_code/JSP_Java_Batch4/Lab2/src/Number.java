//Lab 2-2.2
import java.util.Scanner;
public class Number {

	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		int number;
		
		System.out.println("Enter number: ");
		number = sc.nextInt();
		
		if(number < 0)
		{
			System.out.println(number+" is Negative Number");
		}
		else
		{
			System.out.println(number+" is Positive Number");
		}

	}

}
