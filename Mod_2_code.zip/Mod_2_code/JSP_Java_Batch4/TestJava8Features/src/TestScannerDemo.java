import java.awt.List;
import java.util.Arrays;
import java.util.stream.Stream;

interface MaxFiner
{
	public int max(int num1,int num2);
}


public class TestScannerDemo
{
	public static void main(String[] args)
	{
		List<String> cityList = Arrays.asList("Pune","Mumbai","Nagpur","Gaziabad","Delhi","Mumbai"," ");
		
		cityList.stream().distinct().forEach(System.out::println);
		System.out.println("*********************************");
		
		long cityCount = cityList.stream().distinct().count();
		System.out.println("How Many Cities ? "+cityCount);
		
		System.out.println("*********************************");
		cityList.stream().map(str->str.length()).forEach(System.out::println);
		
	}
}
