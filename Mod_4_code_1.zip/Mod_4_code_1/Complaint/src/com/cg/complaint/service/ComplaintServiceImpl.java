package com.cg.complaint.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.complaint.dao.IComplaintDao;
import com.cg.complaint.dto.Complaint;


@Service("cSer")
@Transactional
public class ComplaintServiceImpl implements IComplaintService
{
	@Autowired
	IComplaintDao cDao;
	
	@Override
	public void addComplaint(Complaint com) 
	{
		cDao.addComplaint(com);
	}

	@Override
	public List<Complaint> showComplaintById(int comId) 
	{
		return cDao.showComplaintById(comId);
	}

}
