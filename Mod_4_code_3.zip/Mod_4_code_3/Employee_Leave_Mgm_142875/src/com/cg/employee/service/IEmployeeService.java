package com.cg.employee.service;

import java.util.List;

import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeave;

public interface IEmployeeService 
{
	public EmployeeDetails findEmployee(int eid);
	
	public EmployeeLeave findLeave(int eid);
	
	public boolean searchEmployee(int eid);
	
	public List<EmployeeLeave> showEmployeeById(int eId);
	
	public boolean searchLeave (int empid);
	
	public List<EmployeeDetails> showDataById(int eid);
}
