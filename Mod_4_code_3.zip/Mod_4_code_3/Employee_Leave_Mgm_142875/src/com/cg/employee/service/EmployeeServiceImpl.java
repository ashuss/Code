package com.cg.employee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.dao.IEmployeeDao;
import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeave;

@Service("empSer")
@Transactional
//service class will implements service interface&override all methods
//marking the service class with spring's @Service annotations
public  class EmployeeServiceImpl implements IEmployeeService
{
	//create Dao interface type variable followed by getters &setters
		//marks the variable with spring's @Autowired annotation
	@Autowired
	IEmployeeDao empDao;

	public boolean searchEmployee(int eid) 
	{
		EmployeeDetails ed = empDao.findEmployee(eid);
		if(ed != null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public List<EmployeeLeave> showEmployeeById(int eId) 
	{
		return empDao.showEmployeeById(eId);
	}

	@Override
	public EmployeeDetails findEmployee(int eid) 
	{
		return empDao.findEmployee(eid);
	}

	@Override
	public boolean searchLeave(int empid) 
	{
		EmployeeLeave el = empDao.findLeave(empid);
		if(el != null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public List<EmployeeDetails> showDataById(int eid) 
	{
		return empDao.showDataById(eid);
	}

	@Override
	public EmployeeLeave findLeave(int eid) 
	{
		return empDao.findLeave(eid);
	}

}
