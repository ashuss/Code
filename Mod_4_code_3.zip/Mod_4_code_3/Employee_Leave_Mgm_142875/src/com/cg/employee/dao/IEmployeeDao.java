package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeave;

public interface IEmployeeDao 
{
	public EmployeeDetails findEmployee(int eid);	//Valid employee or not
	
	public List<EmployeeLeave> showEmployeeById(int eId);		//Display all employee leave details
	
	public List<EmployeeDetails> showDataById(int eid);		//Display all employee details
	
	public EmployeeLeave findLeave(int eid);		//leave valid or not
}
