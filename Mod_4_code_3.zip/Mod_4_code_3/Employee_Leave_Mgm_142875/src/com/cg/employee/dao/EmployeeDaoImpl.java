package com.cg.employee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeave;

@Repository("empDao")
public class EmployeeDaoImpl implements IEmployeeDao
{
	//creating  EntityManager instance and mark it with @PersistenceContext
	@PersistenceContext
	EntityManager entitymanager;
	
	
	@Override
	public List<EmployeeLeave> showEmployeeById(int eId) 
	{
		Query queryOne=entitymanager.createQuery("Select e FROM EmployeeLeave e WHERE empId=:eId");
		queryOne.setParameter("eId", eId);
		
		 List<EmployeeLeave> myList=queryOne.getResultList();
		 return myList;
	}

	@Override
	public EmployeeDetails findEmployee(int eid)
	{
		EmployeeDetails emp = entitymanager.find(EmployeeDetails.class, eid);			
		return emp;
	}

	@Override
	public List<EmployeeDetails> showDataById(int eid) 
	{
		Query queryTwo=entitymanager.createQuery("Select ed FROM EmployeeDetails ed WHERE empId=:eId");
		queryTwo.setParameter("eId", eid);
		
		 List<EmployeeDetails> myList1 = queryTwo.getResultList();
		 return myList1;
	}

	@Override
	public EmployeeLeave findLeave(int eid) 
	{
		EmployeeLeave leave = entitymanager.find(EmployeeLeave.class, eid);			
		return leave;
	}

}
