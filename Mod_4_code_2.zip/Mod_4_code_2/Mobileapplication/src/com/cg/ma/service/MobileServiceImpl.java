package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dao.MobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.Mobile;

public class MobileServiceImpl 
implements MobileService
{
	MobileDao mdao = new MobileDaoImpl();

	@Override
	public void addMobile(Mobile mobile) 
	{
		mdao.addMobile(mobile);
		
	}

	@Override
	public void updateMobile(Mobile mobile) 
	{
		mdao.updateMobile(mobile);
		
	}

	@Override
	public void deleteMobile(Mobile mobile) 
	{
		mdao.deleteMobile(mobile);
		
	}

	@Override
	public Mobile findMobile(int mid) 
	{
		return mdao.findMobile(mid);
	}

	@Override
	public List<Mobile> getallMobiles() 
	{
		return mdao.getallMobiles();
	}

	@Override
	public List<Mobile> fetchMobileInPriceRange(double min, double max) 
	{
		return mdao.fetchMobileInPriceRange(min, max);
	}
	
}
