package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dto.Mobile;

public interface MobileService
{
	void addMobile(Mobile mobile);
	
	void updateMobile(Mobile mobile);
	
	void deleteMobile(Mobile mobile);
	
	Mobile findMobile(int mid);
	
	List<Mobile> getallMobiles();
	
	List<Mobile> fetchMobileInPriceRange(double min, double max);
}
