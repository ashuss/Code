package com.cg.ma.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.ma.dto.Mobile;
import com.cg.ma.service.MobileService;
import com.cg.ma.service.MobileServiceImpl;

public class MobileAdmin 
{

	public static void main(String[] args) 
	{
		MobileService mser = new MobileServiceImpl();
		int choice;
		Scanner sc = new Scanner(System.in);
		do
		{
			System.out.println("1. Add Mobile");
			System.out.println("2. Update Mobile");
			System.out.println("3. Search Mobile");
			System.out.println("4. Delete Mobile");
			System.out.println("5. Show All Mobiles");
			System.out.println("6. Show All Mobiles In Range");
			System.out.println("7. Exit");
			
			System.out.println("Enter Your Choice : ");
			choice = sc.nextInt();
			
			switch(choice)
			{
			case 1: 
				System.out.println("Enter Mobile Name : ");
				sc.nextLine();
				String mname = sc.nextLine();				//space between two words
				System.out.println("Enter Price : ");
				double price = sc.nextDouble();
				System.out.println("Enter Quantity : ");
				int qty = sc.nextInt();
				
				Mobile mobile = new Mobile();
				
				mobile.setName(mname);
				mobile.setPrice(price);
				mobile.setQty(qty);
				
				mser.addMobile(mobile);
				
				System.out.println("Mobile Details Added ");
				
				break;
				
			case 2:
				System.out.println("Enter Mobile Id : ");
				int mid2 = sc.nextInt();
				Mobile mobile3 = mser.findMobile(mid2);
				mser.updateMobile(mobile3);
				System.out.println("Mobile Details Updated");
				break;
				
			case 3:
				System.out.println("Enter Mobile Id to search : ");
				int mid = sc.nextInt();
				Mobile mobile1 = mser.findMobile(mid);
				System.out.println(mobile1);
				break;
				
			case 4:
				System.out.println("Enter mobile Id to delete : ");
				int mid1 = sc.nextInt();
				Mobile mobile2 = mser.findMobile(mid1);
				mser.deleteMobile(mobile2);
				System.out.println("Mobile Details deleted");
				break;
				
			case 5:
				List<Mobile> mlist = mser.getallMobiles();
				for(Mobile m:mlist)
				{
					System.out.println(m);
				}
				break;
			
			case 6:
				System.out.println("Enter Minimum Price Range : ");
				double pmin = sc.nextDouble();
				System.out.println("Enter Maximum Price Range : ");
				double pmax = sc.nextDouble();
				List<Mobile> moblist = mser.fetchMobileInPriceRange(pmin, pmax);
				for(Mobile m:moblist)
				{
					System.out.println(m);
				}
				break;
				
			case 7: System.exit(0);
				
			}
		}
		while(true);
		

	}

}
