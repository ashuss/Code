package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.dto.Mobile;

public interface MobileDao 
{

	void addMobile(Mobile mobile);
	
	void updateMobile(Mobile mobile);
	
	void deleteMobile(Mobile mobile);
	
	Mobile findMobile(int mid);
	
	List<Mobile> getallMobiles();
	
	List<Mobile> fetchMobileInPriceRange(double min, double max);
}
