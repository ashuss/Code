package com.cg.mobile.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mobilemanagement")
public class Mobile 
{
	@Id
	@Column(name="mob_id")
	private int mobId;
	
	@Column(name="mob_name")
	private String mobName;
	
	@Column(name="mob_cat")
	private String mobCat;
	
	@Column(name="price")
	private double mobPrice;
	
	@Column(name="mode_pay")
	private String mode;

	public int getMobId() {
		return mobId;
	}

	public void setMobId(int mobId) {
		this.mobId = mobId;
	}

	public String getMobName() {
		return mobName;
	}

	public void setMobName(String mobName) {
		this.mobName = mobName;
	}

	public String getMobCat() {
		return mobCat;
	}

	public void setMobCat(String mobCat) {
		this.mobCat = mobCat;
	}

	public double getMobPrice() {
		return mobPrice;
	}

	public void setMobPrice(double mobPrice) {
		this.mobPrice = mobPrice;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}
	
	
}
