package com.cg.mobile.dao;

import java.util.List;

import com.cg.mobile.dto.Mobile;


public interface IMobileDao 
{
	public void addMobileData(Mobile mob);
	
	public List<Mobile> showAllMobile();
}
