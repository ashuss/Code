package com.cg.mobile.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.mobile.dto.Mobile;
import com.cg.mobile.service.IMobileService;


@Controller
public class MyController 
{
	@Autowired
	IMobileService mobileservice;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "home";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addMobile(@ModelAttribute("my") Mobile mob, Map<String,Object> model)
	{
		List<String> myCat = new ArrayList<>();
		myCat.add("Samsung");
		myCat.add("Nokia");
		myCat.add("Apple");
		myCat.add("Vivo");
		model.put("deg",myCat);
		return "addmobile";
		
	}
}
